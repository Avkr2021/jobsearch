<!doctype html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <meta name="robots" content="noindex" />
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
      <link rel="stylesheet" href="assets/css/style.css">
      <!-- <link rel="shortcut icon" href="image/favicon.png" type="image/x-icon"> -->
      <!-- Bootstrap , fonts & icons  -->
      <link rel="stylesheet" href="css/bootstrap.css">
      <link rel="stylesheet" href="fonts/icon-font/css/style.css">
      <link rel="stylesheet" href="fonts/typography-font/typo.css">
      <link rel="stylesheet" href="fonts/fontawesome-5/css/all.css">
      <!-- Plugin'stylesheets  -->
      <link rel="stylesheet" href="plugins/fancybox/jquery.fancybox.min.css">
      <link rel="stylesheet" href="plugins/nice-select/nice-select.min.css">
      <link rel="stylesheet" href="plugins/slick/slick.min.css">
      <link rel="stylesheet" href="plugins/ui-range-slider/jquery-ui.css">
      <!-- Vendor stylesheets  -->
      <link rel="stylesheet" href="css/main.css">
      <!-- Custom stylesheet -->
      <title>Developer Testing</title>
      <style>
      </style>
   </head>
   <body>
      <div class="outer_box">
         <!-- header admin -->
         <?php include 'includes/new_admin_header.php' ?>
         <!-- header admin -->
         <div class="main_dashboard_area_outer">
            <!-- nav admin -->
            <?php include 'includes/new_admin_nav.php' ?>
            <!-- nav admin -->
            <div id="cm_4_id" class="cm_3 main_dashboard_inner_two w70">
               <!-- +++++++++++++++++++++ tab one ++++++++++++++++++++++ -->
               <div class="cm_admin tabPanel">
                  <section class="outer_main_div">
                     <div class="container-fluid">
                         <div id="get_message_data" class="row">

                         </div>
                      </div>
                  <div style="height: 20px;"></div>
                  </section>
               </div>
               <!-- +++++++++++++++++++++ tab two ++++++++++++++++++++++ -->
            </div>
         </div>
      </div>
      <!-- +++++++++++++++ Put your all code before this line ++++++++++++ -->
      <!-- +++++++++++++++++++ code end +++++++++++++++++ -->
      <script src="assets/jquery/jquery.js"></script>
      <script src="plugins/fancybox/jquery.fancybox.min.js"></script>
      <script src="plugins/nice-select/jquery.nice-select.min.js"></script>
      <script src="plugins/aos/aos.min.js"></script>
      <script src="plugins/slick/slick.min.js"></script>
      <script src="plugins/counter-up/jquery.counterup.min.js"></script>
      <script src="plugins/counter-up/jquery.waypoints.min.js"></script>
      <script src="plugins/ui-range-slider/jquery-ui.js"></script>
      <script src="js/custom.js"></script>
      <script>
         $(document).ready(function () {
           $('#toggle_btn').click(function () {
             $('#cm_3_id').toggleClass('invisible');
             $('#cm_4_id').toggleClass('invisibleTwo');
           })
         });
         
         function get_message() {
            $.ajax({
               url: 'ajaxfils/get_message.php',
               type: 'POST',
               success: function (data) {
                  $('#get_message_data').html(data);
               }
            })
         }
         get_message();

      </script>
      <script type="text/javascript">
         $(function($) {
            let url = window.location.href;
            $('ul.admin_ul li a').each(function() {
              if (this.href === url) {
                $(this).closest('a').addClass('active_nav_admin');
              }
            });
          });
      </script>
   </body>
</html>