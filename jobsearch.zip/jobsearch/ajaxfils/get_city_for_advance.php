<?php  
include '../includes/config.php';
$sql = "SELECT * FROM cityname";
$result = mysqli_query($conn, $sql);
$output = "";
if (mysqli_num_rows($result) > 0) {
	$output .= "<option>Any</option>";
	while ($row = mysqli_fetch_assoc($result)) {
		$output .= "<option value='{$row['city_name']}'>{$row['city_name']}</option>";
	}
	echo $output;
} else {
	echo "<h6>No data found</h6>";
}



?>