<?php 
include '../includes/config.php';
$search_value = $_POST['search'];
$sql = "SELECT * FROM applicants INNER JOIN job_post ON applicants.applied_for = job_post.job_id WHERE appli_name LIKE '%{$search_value}%' OR appli_location LIKE '%{$search_value}%'";

$result = mysqli_query($conn , $sql) or die('query failed');

$output = "";

if (mysqli_num_rows($result) > 0) {
	while ($row = mysqli_fetch_assoc($result)) {
	$output .= "<tr>
					<td>{$row["appli_name"]}</td>
					<td>{$row["appli_age"]}</td>
					<td>{$row["appli_mobile"]}</td>
					<td>{$row["job_title"]}</td>
					<td>{$row["appli_english"]}</td>
					<td>{$row["appli_experience"]}</td>
					<td>{$row["appli_location"]}</td>
					<td>{$row["appli_date"]}</td>
					<td><button class='view_pdf_two' id='file_btn_view' data-pdf-id='{$row['appli_file']}'>View PDF</button></td>
					
				</tr>";
	}
	mysqli_close($conn);
	echo $output;

} else {
	echo "<h2>No Records Found</h2>";
}
// Name	Mobile	Applied For	English	Work Experience	Location	Date	View
// `appli_id`, `appli_name`, `appli_email`, `appli_mobile`, `appli_experience`, `appli_salary`, `appli_asking`, `appli_location`, `appli_english`, `appli_gender`, `appli_file`, `appli_date`, `appli_time`, `appli_view`, `applied_for`
?>