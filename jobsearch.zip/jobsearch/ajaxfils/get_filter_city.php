<?php  
include '../includes/config.php';
$get_city_ph = $_POST['get_city_key'];
//$sql = "SELECT * FROM applicants WHERE appli_admin_location='$get_city_ph'";
$sql = "SELECT * FROM applicants INNER JOIN job_post ON applicants.applied_for = job_post.job_id WHERE appli_admin_location='$get_city_ph' ORDER BY appli_id DESC";
$result = mysqli_query($conn, $sql);
$output = "";
if (mysqli_num_rows($result) > 0) {
	while ($row = mysqli_fetch_assoc($result)) {
			$output .= "<tr>
		                  <td>{$row['appli_name']}</td>
		                  <td>{$row['appli_age']}</td>
			              <td>{$row['appli_mobile']}</td>
			              <td>{$row['job_title']}</td>
			              <td>{$row['appli_english']}</td>
			              <td>{$row['appli_experience']}</td>
			              <td>{$row['appli_location']}</td>
			              <td>{$row['appli_date']}</td>
			              <td><button id='file_btn_view' data-pdf-id='{$row['appli_file']}'>View PDF</button></td>
			           </tr>";
	}
	echo "$output";
	
} else {
	echo "<h3 class='text-center'>No Records Found !</h3>";
}

?>