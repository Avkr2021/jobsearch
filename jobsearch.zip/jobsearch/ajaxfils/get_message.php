<?php  
include '../includes/config.php';
$sql = "SELECT * FROM company_mail ORDER BY com_id DESC";
$result = mysqli_query($conn , $sql);
$output = "";
if (mysqli_num_rows($result) > 0) {
	while ($row = mysqli_fetch_assoc($result)) {
		$output .= "<div class='col-md-4 down_gap_message'>
	                   <div class='panel_message panel-primary'>
	                      <div class='panel_heading'>
	                         <div class='review_author text-left'>
	                            <span>{$row['com_name']}</span>
	                         </div>
	                      </div>
	                      <div class='message_subject panel_body'>
                             <h6>{$row['com_subject']}</h6>
                          </div>
	                      <div class='panel_body'>
	                         <p>{$row['com_message']}</p>
	                         <div class='contact_details_email'>
	                            <a href='mailto:{$row['com_email']}'>{$row['com_email']}</a><br>
	                         </div>
	                      </div>
	                      <div class='panel_footer text-right'>
	                        <em>{$row['com_date']}</em>
	                      </div>
	                   </div>
	                </div>";
	}
	echo $output;
} else {
	echo "<h6>No records found</h6>";
}
// SELECT `com_id`, `com_name`, `com_email`, `com_subject`, `com_message`, `com_date`, `com_time` FROM `company_mail` WHERE 1


?>