<?php  
include '../includes/config.php';

$get_data_name = $_POST['name_key'];
$get_data_mobile = $_POST['mobile_key'];
$dateCm_ph = date('d/m/Y');
$sql = "INSERT INTO `visitor_info`(`visit_name`, `visit_mobile`,`visit_date`) VALUES ('$get_data_name','$get_data_mobile','$dateCm_ph')";
$result = mysqli_query($conn , $sql);
if ($result) {
	echo "0";
} else {
	echo "1";
}

?>