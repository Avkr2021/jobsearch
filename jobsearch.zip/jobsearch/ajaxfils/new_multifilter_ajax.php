<?php  
include '../includes/config.php';
$start_key_ph = $_POST['start_key'];
$end_key_ph = $_POST['end_key'];
$sql = "SELECT * FROM applicants INNER JOIN job_post ON applicants.applied_for = job_post.job_id WHERE appli_date BETWEEN '".$start_key_ph."' AND '".$end_key_ph."' ORDER BY appli_id DESC";
$result = mysqli_query($conn, $sql);
$output = "";
if (mysqli_num_rows($result) > 0) {
	while ($row = mysqli_fetch_assoc($result)) {
			$output .= "<tr id='task-1'
			              class='task-list-row' 
			              data-jobtitle='{$row['job_title']}'
			              data-gender='{$row['appli_gender']}'
			              data-location='{$row['appli_admin_location']}'
			              data-english='{$row['appli_english']}'>
			            <td>{$row['appli_name']}</td>
			            <td>{$row['job_title']}</td>
			            <td>{$row['appli_admin_location']}</td>
			            <td>{$row['appli_age']}</td>
			            <td>{$row['appli_gender']}</td>
			            <td>{$row['appli_english']}</td>
			            <td>{$row['appli_email']}</td>
			            <td>{$row['appli_mobile']}</td>
			            <td>{$row['appli_date']}</td>
			            <td>{$row['appli_experience']}</td>
			            <td>{$row['appli_location']}</td>
			            <td><button class='view_pdf' id='file_btn_view' data-pdf-id='{$row['appli_file']}'>View PDF</button></td>
			            <input type='hidden' value='{$row['appli_admin_location']}'>
			          </tr>";
	}
	echo "$output";
	
} else {
	echo "<h3 class='text-center'>No Records Found !</h3>";
}


?>