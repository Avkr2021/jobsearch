<?php 
include '../includes/config.php';
$city_name = $_POST['city_name_key'];
$city_status = '1';
$sql = "INSERT INTO `cityname`(`city_name`, `status`) VALUES ('$city_name','$city_status')";
$result = mysqli_query($conn, $sql);
if ($result) {
	echo "0";
} else {
	echo "1";
}


?>