<?php  
include '../includes/config.php';
$sql = "SELECT count(appli_id) as cn from applicants";
$result = mysqli_query($conn , $sql);
$row = mysqli_fetch_array($result);
echo $row['cn'];

?>