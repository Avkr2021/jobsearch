<?php  
include '../includes/config.php';
$sql = "SELECT * FROM `job_post` ORDER BY job_id DESC";
$result = mysqli_query($conn, $sql);
$output = "";
if (mysqli_num_rows($result) > 0) {
	while ($row = mysqli_fetch_assoc($result)) {
			$output .= "<tr>
			              <td>{$row['job_title']}</td>
			              <td>{$row['job_location']}</td>
			              <td>{$row['job_mobile']}</td>
			              <td>{$row['job_date']}</td>
			              <td><button class='do_job_disable' id='disable_post' data-jobpost='{$row['job_id']}'>g</button></td>
			           </tr>";
	}
	echo "$output";
	
} else {
	echo "<h3 class='text-center'>No Records Found !</h3>";
}
 //`job_id`, `job_bullet`, `job_description`, `job_location`, `job_schedule`, `job_education`, `job_experience`, `job_mobile`, `job_date`, `job_time`, `job_status`, `job_title`, `job_salary`
// header('content-type: application/pdf');
// echo readfile('applicant_pdf/641052106.pdf');
?>