<?php  
include '../includes/config.php';
$edit_title_ph  = mysqli_real_escape_string($conn, $_POST['edit_title_key']);
$edit_location_ph = mysqli_real_escape_string($conn, $_POST['edit_location_key']);
$edit_education_ph = mysqli_real_escape_string($conn, $_POST['edit_education_key']);
$edit_description_ph = mysqli_real_escape_string($conn, $_POST['edit_description_key']);
$edit_mobile_ph = mysqli_real_escape_string($conn, $_POST['edit_mobile_key']);
$edit_salary_ph = mysqli_real_escape_string($conn,$_POST['edit_salary_key']);

$sql = "UPDATE `job_post` SET `job_description`='$edit_description_ph',`job_location`='$edit_location_ph',`job_schedule`='[value-5]',`job_education`='$edit_education_ph',`job_mobile`='$edit_mobile_ph',`job_date`='[value-9]',`job_time`='[value-10]',`job_title`='$edit_title_ph',`job_salary`='$edit_salary_ph'";
$


?>