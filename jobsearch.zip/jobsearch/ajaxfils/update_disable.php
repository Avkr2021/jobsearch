<?php  
include '../includes/config.php';
$get_disable_ph = $_POST['get_disable_key'];
$sql = "UPDATE `job_post` SET `job_status`='0' WHERE job_id='$get_disable_ph'";
$result = mysqli_query($conn , $sql);
if ($result) {
	echo "0";
} else {
	echo "1";
}

?>