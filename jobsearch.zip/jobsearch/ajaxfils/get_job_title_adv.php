<?php  
include '../includes/config.php';
$sql = "SELECT * FROM `job_post` ORDER BY job_id DESC";
$result = mysqli_query($conn, $sql);
$output = "";
if (mysqli_num_rows($result) > 0) {
	        $output .= "<option>Any</option>";
	while ($row = mysqli_fetch_assoc($result)) {
			$output .= "<option>{$row['job_title']}</option>";
	}
	echo "$output";
	
} else {
	echo "<h3 class='text-center'>No Records Found !</h3>";
}

?>