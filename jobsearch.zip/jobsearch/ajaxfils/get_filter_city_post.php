<?php  
include '../includes/config.php';
$get_city_ph = $_POST['get_city_key'];
//$sql = "SELECT * FROM applicants WHERE appli_admin_location='$get_city_ph'";
$sql = "SELECT * FROM `job_post` WHERE job_location='$get_city_ph' AND job_status='1' ORDER BY job_id DESC";

$result = mysqli_query($conn, $sql);
$output = "";
if (mysqli_num_rows($result) > 0) {
	while ($row = mysqli_fetch_assoc($result)) {
			$output .= "<tr>
			              <td>{$row['job_title']}</td>
			              <td>{$row['job_location']}</td>
			              <td>{$row['job_mobile']}</td>
			              <td>{$row['job_date']}</td>
			              <td><button class='do_job_disable' id='disable_post' data-jobpost='{$row['job_id']}'>Disable</button></td>
			           </tr>";
	}
	echo "$output";
	
} else {
	echo "<h3 class='text-center'>No Records Found !</h3>";
}

?>