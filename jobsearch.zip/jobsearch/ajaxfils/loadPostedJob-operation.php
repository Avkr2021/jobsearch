<?php  
include '../includes/config.php';
$sql = "SELECT * FROM `job_post` ORDER BY job_id DESC";
$result = mysqli_query($conn, $sql);
$output = "";
if (mysqli_num_rows($result) > 0) {
	while ($row = mysqli_fetch_assoc($result)) {
			$output .= "<tr>
			              <td><input class='tagid' type='text' tag='{$row['job_id']}' id='edit_title' disabled value='{$row['job_title']}'></td>
			              <td><input class='tagid' tag='{$row['job_id']}' id='edit_location' disabled value='{$row['job_location']}'></td>
			              <td><input class='tagid' tag='{$row['job_id']}' id='edit_education' disabled value='{$row['job_education']}'></td>
			              <td><textarea class='tagid' tag='{$row['job_id']}' id='edit_description' disabled>{$row['job_description']}</textarea></td>
			              <td><input class='tagid' tag='{$row['job_id']}' id='edit_mobile' disabled value='{$row['job_mobile']}'></td>
			              <td><input class='tagid' tag='{$row['job_id']}' id='edit_salary' disabled value='{$row['job_salary']}'></td>
			              <td><button class='tagid operation_edit_delete btn-success' id='save_data' disabled>Save</button></td>
			              <td>
			              <button class='operation_edit_delete btn-warning' id='edit_post' data-jobposted='{$row['job_id']}'>Edit</button><span class='width:10px;'></span>
			              <button class='operation_edit_delete btn-danger' id='delete_post' data-jobpostdl='{$row['job_id']}'>Delete</button>
			              </td>
			           </tr>";
	}
	echo "$output";
	
} else {
	echo "<h3 class='text-center'>No Records Found !</h3>";
}



 //`job_id`, `job_bullet`, `job_description`, `job_location`, `job_schedule`, `job_education`, `job_experience`, `job_mobile`, `job_date`, `job_time`, `job_status`, `job_title`, `job_salary`
// header('content-type: application/pdf');
// echo readfile('applicant_pdf/641052106.pdf');
?>