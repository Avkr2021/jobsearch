<?php  
include '../includes/config.php';
$receiver = $_POST['get_job_id_key'];
$sql = "SELECT * FROM `job_post` WHERE job_id = '$receiver'";
$result = mysqli_query($conn , $sql);
//--------------------

$output = "";
if (mysqli_num_rows($result) > 0) {
	while ($row = mysqli_fetch_assoc($result)) {
		$output = "<div class='set_scroll_inner_new'>
                           <div class='apply_heder'>
                              <div class='side_padding'>
                                 <div class='inner_side_id'>
                                   <div>
                                      <a class='btn btn-green btn-h-60 btn-primary w-180 rounded-5 text-uppercase mx-auto mx-lg-0' data-btn-id='' href='apply.php?job-id={$row['job_id']}'>Apply now</a>
                                   </div>
                                   <div>
                                      <h3 class='full_discript'>{$row['job_title']}</h3>
                                   </div>
                                </div>
                              </div>
                           </div>
                           <div class='job_list job_list_two'>
                              <div class='job_list_inner'>
                                 <div class='full_text'>
                                    <p class='full_text_one'>{$row['job_description']}</p>
                                 </div>
                                 
                                 <div class='payout'>
                                    <p></p>
                                    <p></p>
                                    <p>Salary: ₹ <span>{$row['job_salary']}</span> per month</p>
                                 </div>
                                 <div class='schedule_sec'>
                                    <h6>Key Points:</h6>
                                    <div class='job_list_added'>
                                       <ul id='get_bullet_point_mobile'>
                                       <input id='gt_ul_value' type='hidden' value='{$row['job_bullet']}'>
                                       </ul>
                                    </div>
                                 </div>
                                 <div class='schedule_sec'>
                                    <h6>Schedule:</h6>
                                    <p>{$row['job_schedule']}</p>
                                 </div>
                                 <div class='schedule_sec'>
                                    <h6>Education:</h6>
                                    <p>{$row['job_education']}</p>
                                 </div>
                                 <div class='schedule_sec'>
                                    <h6>Experience:</h6>
                                    <ul id='experience_point_mobile'>

                                    </ul>
                                 </div>
                                 <div class='dalk_with_employe'>
                                    <h6>Speak with the employer</h6>
                                    <a href='tel:{$row['job_mobile']}'>{$row['job_mobile']}</a>
                                 </div>
                              </div>
                           </div>
                        </div>";
	}
	echo $output;
} else {
	echo "0";
}

?>