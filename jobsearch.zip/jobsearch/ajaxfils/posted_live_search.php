<?php 
include '../includes/config.php';
$search_value = $_POST['search'];
//$sql = "SELECT * FROM `job_post` WHERE  ORDER BY job_id DESC";
$sql = "SELECT * FROM job_post  WHERE job_title LIKE '%{$search_value}%' OR job_date LIKE '%{$search_value}%'";

$result = mysqli_query($conn , $sql) or die('query failed');

$output = "";

if (mysqli_num_rows($result) > 0) {
	while ($row = mysqli_fetch_assoc($result)) {
			$output .= "<tr>
			              <td>{$row['job_title']}</td>
			              <td>{$row['job_location']}</td>
			              <td>{$row['job_mobile']}</td>
			              <td>{$row['job_date']}</td>
			              <td><button class='do_job_disable' id='disable_post' data-jobpost='{$row['job_id']}'>Disable</button></td>
			           </tr>";
	}

	mysqli_close($conn);
	echo $output;

} else {
	echo "<h2>No Records Found</h2>";
}

?>