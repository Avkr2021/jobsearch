<?php 	 

include '../includes/config.php';
$get_job_id_bullet_ph = $_POST['get_job_id_bullet_key'];
$sql = "SELECT * FROM `job_post` WHERE job_id = '$get_job_id_bullet_ph'";
$result = mysqli_query($conn, $sql);
$output_one = "";
if (mysqli_num_rows($result) > 0) {
    while ($row_one = mysqli_fetch_assoc($result)) {
    	   $output_one = "{$row_one['job_experience']}";
    }
   $bulletarray = explode("#$", $output_one);
   foreach ($bulletarray as $value) {
   	$getin_il =  "<li>{$value}</li>";
   	echo $getin_il;
   }
}



?>