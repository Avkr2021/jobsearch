<?php
include '../includes/config.php';
	$hidden_job_ph = $_POST['hidden_job_name'];
	$hidden_job_location_ph = $_POST['hidden_job_location'];
	$name_ph = $_POST['user_name'];
	$email_ph = $_POST['user_email'];
	$mobile_ph = $_POST['user_mobile'];
	$age_ph = $_POST['user_age'];
	$experience_ph = $_POST['user_experience'];
	$salary_ph = $_POST['user_salary'];
	$asking_ph = $_POST['user_asking'];
	$location_ph = $_POST['user_location'];
	$communication_ph = $_POST['user_comunination'];
	$gender_ph = $_POST['gender'];
	$file_ph = $_FILES['user_file']['name'];
	$dateCn_ph = date('d/m/Y');
    date_default_timezone_set('Asia/Kolkata');
    $timeCn_ph = date('h:iA');
    $appli_view_ph = '0';
    if ($file_ph !== '') {
    	$file_tmp = $_FILES['user_file']['tmp_name'];
    	$file_ext = pathinfo($file_ph, PATHINFO_EXTENSION);
    	$validExt = array('pdf');
    	if (in_array($file_ext  , $validExt)) {
    		$new_pdf_name = rand().'.'.$file_ext;
    		$path = '../applicant_pdf/' . $new_pdf_name;
    	} else {
    		echo "1";
    		die();
    	}
    }
if (!empty($name_ph) && !empty($email_ph) && !empty($mobile_ph) && !empty($experience_ph) && !empty($salary_ph) && !empty($asking_ph) && !empty($location_ph) && !empty($communication_ph) && !empty($gender_ph) && !empty($file_ph)) {
	move_uploaded_file($_FILES['user_file']['tmp_name'], $path);
	$sql = "INSERT INTO `applicants`(`appli_name`, `appli_age`, `appli_email`, `appli_mobile`, `appli_experience`, `appli_salary`, `appli_asking`, `appli_location`, `appli_english`, `appli_gender`, `appli_file`, `appli_date`, `appli_time`, `appli_view`, `applied_for`,`appli_admin_location`) VALUES ('$name_ph','$age_ph','$email_ph','$mobile_ph','$experience_ph','$salary_ph','$asking_ph','$location_ph','$communication_ph','$gender_ph','$new_pdf_name','$dateCn_ph','$timeCn_ph','$appli_view_ph','$hidden_job_ph','$hidden_job_location_ph')";
	$result = mysqli_query($conn, $sql);
	if ($result) {
		echo "0";
	} else {
		echo "2";
	}
} else {
	echo "3";
}



?>