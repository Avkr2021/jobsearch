<?php  
include '../includes/config.php';
$sql = "SELECT count(job_id) as cn from job_post";
$result = mysqli_query($conn , $sql);
$row = mysqli_fetch_array($result);
echo $row['cn'];


?>