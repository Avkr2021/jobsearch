<?php  
include '../includes/config.php';
$get_id_ph = $_POST['job_id'];
$get_status_ph = $_POST['get_status_key'];
$set_deactivate = '';
if ($get_status_ph == 1) {
	$set_deactivate = '0';
} else {
	$set_deactivate = '1';
}
$sql = "UPDATE `job_post` SET job_status ='$set_deactivate' WHERE job_id='$get_id_ph'";
$result = mysqli_query($conn, $sql);
if ($result) {
	echo "0";
} else {
	echo "1";
}


?>