<?php  
include '../includes/config.php';
$nameCm_ph = $_POST['nameCm_key'];
$emailCm_ph = $_POST['emailCm_key'];
$subjectCm_ph = $_POST['subjectCm_key'];
$messageCm_ph = mysqli_real_escape_string($conn, $_POST['messageCm_key']);
$dateCm_ph = date('d/m/Y');
date_default_timezone_set('Asia/Kolkata');
$timeCm_ph = date('h:iA');
// echo $dateCm_ph .' '.$timeCm_ph;
// echo $nameCm_ph .' '.$emailCm_ph .' '.$subjectCm_ph .' '.$messageCm_ph ;
$sql = "INSERT INTO `company_mail`(`com_name`, `com_email`, `com_subject`, `com_message`, `com_date`, `com_time`) VALUES ('$nameCm_ph','$emailCm_ph','$subjectCm_ph','$messageCm_ph','$dateCm_ph','$timeCm_ph')";

$result = mysqli_query($conn, $sql);

echo $result;
die();
if ($result) {
	echo "0";
} else {
	echo "1";
}
die();
// $to = $email_ph;
// $subject = $subject_ph .' '.$selected_ph;
// $message = 'Dont Replay Back If you get this message';
// "<!DOCTYPE html>
// <html>
//    <head>
//       <title>Test Email Sample</title>
//       <meta http-equiv='Content-Type' content='text/html; charset=UTF-8' />
//       <meta http-equiv='X-UA-Compatible' content='IE=edge' />
//       <meta name='viewport' content='width=device-width, initial-scale=1.0' />
//       <meta name='format-detection' content='telephone=no'>
//       <link href='https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800' rel='stylesheet'>
//       <style>
//          body {
//          margin: 0 !important;
//          padding: 0 !important;
//          -webkit-text-size-adjust: 100% !important;
//          -ms-text-size-adjust: 100% !important;
//          -webkit-font-smoothing: antialiased !important;
//          }
//          img {
//          border: 0 !important;
//          outline: none !important;
//          }
//          p {
//          Margin: 0px !important;
//          padding: 0px !important;
//          }
//          table {
//          border-collapse: collapse;
//          mso-table-lspace: 0px;
//          mso-table-rspace: 0px;
//          }
//          td, a, span {
//          border-collapse: collapse;
//          mso-line-height-rule: exactly;
//          }
//          .ExternalClass * {
//          line-height: 100%;
//          }
//          @media yahoo { 
//          .em_img {
//          /*min-width:700px !important;*/
//          } 
//          }
//          .em_img {
//          /*width: 700px !important;*/
//          height: auto !important;
//          }
//          .em_defaultlink a {
//          color: inherit !important;
//          text-decoration: none !important;
//          }
//          span.MsoHyperlink {
//          mso-style-priority: 99;
//          color: inherit;
//          }
//          span.MsoHyperlinkFollowed {
//          mso-style-priority: 99;
//          color: inherit;
//          }
         
//          @media only screen and (min-width:481px) and (max-width:699px) {
//          .em_main_table {
//          width: 100% !important;
//          }
//          .em_wrapper {
//          width: 100% !important;
//          }
//          .em_hide {
//          display: none !important;
//          }
//          .em_img {
//          /*width: 100% !important;*/
//          height: auto !important;
//          }
//          .em_h20 {
//          height: 20px !important;
//          }
//          .em_padd {
//          padding: 20px 10px !important;
//          }
//          }
//          @media screen and (max-width: 480px) {
//          .em_main_table {
//          width: 100% !important;
//          }
//          .em_wrapper {
//          width: 100% !important;
//          }
//          .em_hide {
//          display: none !important;
//          }
//          .em_img {
//          /*width: 100% !important;*/
//          height: auto !important;
//          }
//          .em_h20 {
//          height: 20px !important;
//          }
//          .em_padd {
//          padding: 20px 10px !important;
//          }
//          .em_text1 {
//          font-size: 16px !important;
//          line-height: 24px !important;
//          }
//          u + .em_body .em_full_wrap {
//          width: 100% !important;
//          width: 100vw !important;
//          }
//          }
//          .em_img {
//              display: block;
//              font-family: Arial, sans-serif;
//              font-size: 30px;
//              line-height: 34px;
//              color: #000000;
//              width: 150px;
//              margin-bottom: 20px;
//          }
//          .em_color {
//             background: #ff8046;
//          }
//       </style>
//    </head>
//    <body class='em_body' style='margin:0px; padding:0px;' bgcolor='#efefef'>
//       <table class='em_full_wrap' valign='top' width='100%' cellspacing='0' cellpadding='0' border='0' bgcolor='#efefef' align='center'>
//          <tbody>
//             <tr>
//                <td valign='top' align='center'>
//                   <table class='em_main_table' style='width:700px;' width='700' cellspacing='0' cellpadding='0' border='0' align='center'>
//                      <!--Header section-->
//                      <tbody>
//                         <tr>
//                            <td style='padding:15px;' class='em_padd' valign='top' bgcolor='#f6f7f8' align='center'>
//                               <table width='100%' cellspacing='0' cellpadding='0' border='0' align='center'>
//                                  <tbody>
//                                  </tbody>
//                               </table>
//                            </td>
//                         </tr>
//                         <!--//Header section ends--> 
//                         <!--Banner section-->
//                         <tr>
//                            <td valign='top' align='center'>
//                               <table width='100%' cellspacing='0' cellpadding='0' border='0' align='center'>
//                                  <tbody>
//                                     <tr>
//                                        <td valign='top' align='center'>
//                                           <img class='em_img' alt='weblites' src='http://weblites.in/images/weblites/webliteslogo.webp'>
//                                        </td>
//                                     </tr>
//                                  </tbody>
//                               </table>
//                            </td>
//                         </tr>
//                         <!--//Banner section ends--> 
//                         <!-- <img src='i' alt='Logo' class='ree-logo' /> -->
//                         <!--Content Text Section-->
//                         <tr>
//                            <td>
//                               <div style='text-align: center;'>
//                                  <span style='font-size: 16px; font-weight: 500;'>Hi </span><span style='font-size: 16px; font-weight: 600;'>{$name_ph}</span>
//                               </div>
//                            </td>
//                         </tr>
//                         <tr>
//                            <td style='padding:35px 70px 30px;' class='em_padd' valign='top' align='center'>
//                               <table width='100%' cellspacing='0' cellpadding='0' border='0' align='center'>
//                                  <tbody>
//                                     <tr>
//                                        <td valign='top' align='center' style =' 
//                                           font-size:12px; 
//                                           line-height:23px; 
//                                           color:#000;' 
//                                           >Thanks for writing to us,
//                                           <br>
//                                           We will get back to you within 24 Hours with your query regarding '{$selected_ph}' or you can call or whats App us at <a style='text-decoration: none; color: #000;' href='telto:+919315474135'> 9315474135</a>
//                                        </td>
//                                     </tr>
//                                     <tr>
//                                        <td style='font-size:0px; 
//                                           line-height:0px; 
//                                           height:15px;' 
//                                           height='15'>
//                                           &nbsp;
//                                        </td>
//                                     </tr>
//                                     <tr>
//                                        <td valign='top' align='center' style=' 
//                                           font-size:18px; 
//                                           line-height:22px; 
//                                           color:#656565; 
//                                           letter-spacing:2px; 
//                                           padding-bottom:12px;' 
                                           
//                                           >
//                                           What does this mean? Im glad you asked!
//                                        </td>
//                                     </tr>
//                                     <tr>
//                                        <td class='em_h20' 
//                                           style='font-size:0px; 
//                                           line-height:0px;
//                                           height:25px;' 
//                                           height='25'>
//                                           &nbsp;
//                                        </td>
//                                     </tr>
//                                     <tr>
//                                        <td style=' 
//                                           font-size:16px; 
//                                           line-height:22px; 
//                                           color:#656565; 
//                                           text-transform:uppercase; 
//                                           letter-spacing:2px; 
//                                           padding-bottom:12px;' 
//                                           valign='top' 
//                                           align='center'> 
//                                           Unlocking the mind is the key to get somthing different. And uniqueness is the key to reaching our maximum potential!
//                                        </td>
//                                     </tr>
//                                  </tbody>
//                               </table>
//                            </td>
//                         </tr>
//                         <tr>
//                            <td style='padding:38px 30px;' class='em_padd em_color' valign='top' bgcolor='#f6f7f8' align='center'>
//                               <table width='100%' cellspacing='0' cellpadding='0' border='0' align='center'>
//                                  <tbody>
//                                     <!--Social Media links row -->
//                                     <tr>
//                                        <td style='padding-bottom:16px;' valign='top' align='center'>
//                                           <table cellspacing='0' cellpadding='0' border='0' align='center'>
//                                              <tbody>
//                                                 <tr>
//                                                    <!--Facebook Link -->
//                                                    <td valign='top' align='center'>
//                                                       <a href='https://www.facebook.com/' 
//                                                          target='_blank' 
//                                                          style='text-decoration:none;'>
//                                                       <img src='https://i2.lensdump.com/i/ZBA8wH.png' 
//                                                          alt='fb' 
//                                                          style='display:block; 
//                                                          font-family:Arial, 
//                                                          sans-serif; 
//                                                          font-size:14px; 
//                                                          line-height:14px; 
//                                                          color:#ffffff; 
//                                                          max-width:26px;' 
//                                                          width='26' 
//                                                          border='0' 
//                                                          height='26'>
//                                                       </a>
//                                                    </td>
//                                                    <!--Spacing <td> -->
//                                                    <td style='width:6px;' width='6'>&nbsp;</td>
//                                                    <!--Twitter Link -->
//                                                    <td valign='top' align='center'>
//                                                       <a href='https://twitter.com/TexPosse' 
//                                                          target='_blank' 
//                                                          style='text-decoration:none;'>
//                                                       <img src='https://i.lensdump.com/i/ZBAiKc.png' 
//                                                          alt='twitter' 
//                                                          style='display:block; 
//                                                          font-family:Arial, 
//                                                          sans-serif; 
//                                                          font-size:14px; 
//                                                          line-height:14px; 
//                                                          color:#ffffff; 
//                                                          max-width:27px;' 
//                                                          width='27' 
//                                                          border='0' 
//                                                          height='26'>
//                                                       </a>
//                                                    </td>
//                                                    <!--Spacing <td> -->
//                                                    <td style='width:6px;' width='6'>&nbsp;</td>
//                                                    <!--LinkedIn Link -->
//                                                    <td valign='top' align='center'>
//                                                       <a href='https://linkedin.com/in/chris-muster-832b57a1' 
//                                                          target='_blank' 
//                                                          style='text-decoration:none;'>
//                                                       <img src='https://i3.lensdump.com/i/ZBAW11.png' 
//                                                          alt='linkedin' 
//                                                          style='display:block; 
//                                                          font-family:Arial, 
//                                                          sans-serif; 
//                                                          font-size:14px; 
//                                                          line-height:14px; 
//                                                          color:#ffffff; 
//                                                          max-width:26px;' 
//                                                          width='26' 
//                                                          border='0' 
//                                                          height='26'>
//                                                       </a>
//                                                    </td>
//                                                 </tr>
//                                              </tbody>
//                                           </table>
//                                        </td>
//                                     </tr>
//                                     <!--Other links and info row -->
//                                     <tr>
//                                        <td style='font-family: 
//                                           font-size:10px; 
//                                           line-height:18px;
//                                           font-weight: 300;
//                                           color:#fff;' 
//                                           valign='top' 
//                                           align='center'>
//                                           <a href='http://weblites.in/' 
//                                              target='_blank' 
//                                              style='color:#fff; 
//                                              text-decoration:underline;'>
//                                           www.weblites.in
//                                           </a>
//                                           <br>
//                                           <br>
//                                           © 2022 Weblites. All Rights Reserved.
//                                           <br>
//                                        </td>
//                                     </tr>
//                                  </tbody>
//                               </table>
//                            </td>
//                         </tr>
//                      </tbody>
//                   </table>
//                </td>
//             </tr>
//          </tbody>
//       </table>
//       <div class='em_hide' style='white-space: nowrap; 
//          display: none; 
//          font-size:0px; 
//          line-height:0px;'>
//          &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
//       </div>
//    </body>
// </html>";
// $from = 'info@weblites.in';
// $headers ="MIME-Version: 1.0\r\n";
// $headers .= "Content-Type: text/html; charset=iso-8859-1\r\n";
//$headers .= 'Cc: pankajmaurya4610@gmail.com, ak9353065@gmail.com' . "\r\n";
//$headers .= 'Bcc: pankajmaurya4610@gmail.com, ak9353065@gmail.com' . "\r\n";
//$headers = "From : $from";

// if (mail($to , $subject, $message, $headers)) {
//     echo "1";
// } else {
//     echo "0";
// }






?>