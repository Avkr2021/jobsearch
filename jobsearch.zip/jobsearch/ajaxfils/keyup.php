<?php 

include '../includes/config.php';
$nameCm_ph = $_POST['get_one_key'];
$lastCm_ph = $_POST['get_two_key'];

//echo $nameCm_ph.'|'.$lastCm_ph;

$sql = "INSERT INTO `keyup`(`first_name`, `last_name`) VALUES ('$nameCm_ph','$lastCm_ph')";

$result = mysqli_query($conn, $sql);


if ($result) {
	echo "0";
} else {
	echo "1";
}


?>