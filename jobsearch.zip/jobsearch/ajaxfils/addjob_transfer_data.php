<?php  
include '../includes/config.php';

$job_title_js_ph = $_POST['job_title_js_key'];
$bullet_js_ph = $_POST['bullet_js_key'];
$job_desc_js_ph = mysqli_real_escape_string($conn , $_POST['job_desc_js_key']);
$job_location_js_ph = $_POST['job_location_js_key'];
$job_schedule_js_ph = $_POST['job_schedule_js_key'];
$job_education_js_ph = $_POST['job_education_js_key'];
$job_expr_js_ph = $_POST['job_expr_js_key'];
$job_salary_js_ph = $_POST['job_salary_js_key'];
$job_mobile_js_ph = $_POST['job_mobile_js_key'];
$job_status = '1';
$dateJob_ph = date('d/m/Y');
date_default_timezone_set('Asia/Kolkata');
$timeJob_ph = date('h:iA');
$arr = explode("#$", $bullet_js_ph);
$arr = array_filter($arr);
$bullet_ph = implode("#$", $arr);
$arrn = explode("#$", $job_expr_js_ph);
$arrn = array_filter($arrn);
$bullet_phn = implode("#$", $arrn);
$sqlo = "INSERT INTO `job_post`(`job_bullet`, `job_description`, `job_location`, `job_schedule`, `job_education`, `job_experience`, `job_mobile`, `job_date`, `job_time`, `job_status`,`job_title`,`job_salary`) VALUES ('$bullet_ph','$job_desc_js_ph','$job_location_js_ph','$job_schedule_js_ph','$job_education_js_ph','$bullet_phn','$job_mobile_js_ph','$dateJob_ph','$timeJob_ph','$job_status','$job_title_js_ph', '$job_salary_js_ph')";


$result = mysqli_query($conn, $sqlo);

if ($result) {
	echo "0";
} else {
	echo "1";
}

?>