
<?php     

include '../includes/config.php';
$city_name = $_POST['get_city_key'];
$sql = "SELECT * FROM `job_post` WHERE job_location='$city_name' AND job_status='1' ORDER BY job_id DESC";
$result = mysqli_query($conn, $sql);

$output = "";
if (mysqli_num_rows($result) > 0) {
   while ($row = mysqli_fetch_assoc($result)) {
      $output .= " <div id='job_container' class='mb-8 main_card_box' data-job-id='{$row['job_id']}'>
                        <div class='pt-9 px-xl-9 px-lg-7 px-7 pb-7 light-mode-texts bg-white rounded hover-shadow-3 '>
                           <div class='row'>
                              <div class='col-md-6'>
                                 <div class='media align-items-center'>
                                    <div>
                                       <h3 class='mb-0'><a class='font-size-6 heading-default-color' href='javascript:void(0)'>{$row['job_title']}</a></h3>
                                       <a href='#' class='font-size-3 text-default-color line-height-2'>AirBnb</a>
                                    </div>
                                 </div>
                              </div>
                              <div class='col-md-6 text-right pt-7 pt-md-5'>
                                 <div class='media justify-content-md-end'>
                                    <p class='font-weight-bold font-size-7 text-hit-gray mb-0'><span class='text-black-2'>₹ {$row['job_salary']}</span></p>
                                 </div>
                              </div>
                           </div>
                           <div class='row pt-8'>
                              <div class='col-md-7'>
                                 <ul class='d-flex list-unstyled mr-n3 flex-wrap'>
                                    <li>
                                       <a class='bg-regent-opacity-15 min-width-px-96 mr-3 text-center rounded-3 px-6 py-1 font-size-3 text-black-2 mt-2' href='#'>Agile</a>
                                    </li>
                                    <li>
                                       <a class='bg-regent-opacity-15 min-width-px-96 mr-3 text-center rounded-3 px-6 py-1 font-size-3 text-black-2 mt-2' href='#'>Wireframing</a>
                                    </li>
                                 </ul>
                              </div>
                              <div class='col-md-5'>
                                 <ul class='d-flex list-unstyled mr-n3 flex-wrap mr-n8 justify-content-md-end'>
                                    <li class='mt-2 mr-8 font-size-small text-black-2 d-flex'>
                                       <span class='mr-4' style='margin-top: -2px'><img src='image/svg/icon-loaction-pin-black.svg' alt=''></span>
                                       <span class='font-weight-semibold'>{$row['job_location']}</span>
                                    </li>
                                    <li class='mt-2 mr-8 font-size-small text-black-2 d-flex'>
                                       <span class='mr-4' style='margin-top: -2px'><img src='image/svg/icon-suitecase.svg' alt=''></span>
                                       <span class='font-weight-semibold'>Full-time</span>
                                    </li>
                                    <li class='mt-2 mr-8 font-size-small text-black-2 d-flex'>
                                       <span class='mr-4' style='margin-top: -2px'><img src='image/svg/icon-clock.svg' alt=''></span>
                                       <span class='font-weight-semibold'>{$row['job_date']}</span>
                                    </li>
                                 </ul>
                              </div>
                           </div>
                        </div>
                     </div>";
   }
   echo $output;
} else {
   echo "<h2>No records found</h2>";
}
// `job_post`(`job_id`, `job_bullet`, `job_description`, `job_location`, `job_schedule`, `job_education`, `job_experience`, `job_mobile`, `job_date`, `job_time`, `job_status`, `job_title`, `job_salary`

?>