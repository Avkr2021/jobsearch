<!doctype html>
<html lang="en">
 <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="robots" content="noindex" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- <link rel="shortcut icon" href="image/favicon.png" type="image/x-icon"> -->
    <!-- Bootstrap , fonts & icons  -->
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="fonts/icon-font/css/style.css">
    <link rel="stylesheet" href="fonts/typography-font/typo.css">
    <link rel="stylesheet" href="fonts/fontawesome-5/css/all.css">
    <!-- Plugin'stylesheets  -->
    <link rel="stylesheet" href="plugins/fancybox/jquery.fancybox.min.css">
    <link rel="stylesheet" href="plugins/nice-select/nice-select.min.css">
    <link rel="stylesheet" href="plugins/slick/slick.min.css">
    <link rel="stylesheet" href="plugins/ui-range-slider/jquery-ui.css">
    <!-- Vendor stylesheets  -->
    <link rel="stylesheet" href="css/main.css">
    <!-- Custom stylesheet -->
    <title>Developer Testing</title>
    <style>


    </style>
 </head>
   <body>
      <section class="manin_ul_areaX">
      <?php include 'includes/navbar.php' ?>
      <!-- +++++++++++++  header end +++++++++++ -->

<section class="main_section_area_about_new"> 
    <div class="container">
      <div class=" position-relative align-items-center">
        <div class="row align-items-center">
          <div class="col-md-6 col-sm-10 mb-5">
            <h1 class="font-size-11 mb-12">Lorem ipsum dolor adipisicing elit.</h1>
            <p class="font-size-6">Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui nesciunt nemo reprehenderit quidem repellendus ad</p>
            <div>
              <a class="btn btn-green btn-h-60 btn-primary w-180 rounded-5 text-uppercase mx-lg-0" href="index.php">Find Job</a>
            </div>
          </div>
          <div class="col-md-6 col-sm-12 mb-5">
            <div class="single-image image_outer_radius" data-aos="fade-left" data-aos-duration="800" data-aos-once="true">
              <img src="assets/img/work.webp" alt="hero-image" class="img-fluid">
            </div>
          </div>
        </div>
      </div>
    </div>
</section>
    <section class="main_section_area_about">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-12 col-md-8 col-lg-6 col-xxl-5">
            <div class="text-center mb-8 mb-lg-18 px-xl-9 px-xxl-7">
              <h2 class="font-size-9 mb-6">Lorem ipsum dolor<br class="d-none d-sm-block" > sit amet elit.</h2> 
              <p class="font-size-4 text-default-color px-xs-9 px-md-0">Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui nesciunt nemo reprehenderit quidem</p>
            </div>
          </div>
        </div>
        <div class="row justify-content-center" data-aos="fade-up" data-aos-duration="800" data-aos-once="true">
          <!-- Single Services -->
          <div class="col-12 col-lg-4 col-md-6 col-sm-8 col-xs-8">
            <div class="px-xl-7 px-xxl-12 pt-5 pb-3 pb-lg-9 text-center">
              <div class="square-92 rounded-4 bg-dodger text-white font-size-8 mx-auto shadow-dodger mb-11">
                <img src="image/svg/shoot.svg" alt="">
              </div>
              <div class="services-content">
                <h3 class="font-size-6 mb-7">Lorem ipsum dolor</h3>
                <p class="font-size-4 text-default-color">Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui nesciunt nemo reprehenderit quidem repellendus ad animi,</p>
              </div>
            </div>
          </div>
          <!-- End Single Services -->
          <!-- Single Services -->
          <div class="col-12 col-lg-4 col-md-6 col-sm-8 col-xs-8">
            <div class="px-xl-7 px-xxl-12 pt-5 pb-3 pb-lg-9 text-center">
              <div class="square-92 rounded-4 bg-green text-white font-size-8 mx-auto shadow-green mb-11">
                <img src="image/svg/user.svg" alt="">
              </div>
              <div class="services-content">
                <h3 class="font-size-6 mb-7">Lorem ipsum dolor</h3>
                <p class="font-size-4 text-default-color">Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui nesciunt nemo reprehenderit quidem repellendus ad animi,</p>
              </div>
            </div>
          </div>
          <!-- End Single Services -->
          <!-- Single Services -->
          <div class="col-12 col-lg-4 col-md-6 col-sm-8 col-xs-8">
            <div class="px-xl-7 px-xxl-12 pt-5 pb-3 pb-lg-9 text-center">
              <div class="square-92 rounded-4 bg-casablanca text-white font-size-8 mx-auto shadow-casablanca mb-11">
                <img src="image/svg/heart.svg" alt="">
              </div>
              <div class="services-content">
                <h3 class="font-size-6 mb-7">Lorem ipsum dolor</h3>
                <p class="font-size-4 text-default-color">Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui nesciunt nemo reprehenderit quidem repellendus ad animi,</p>
              </div>
            </div>
          </div>
          <!-- End Single Services -->
        </div>
        <!-- End Services Content -->
      </div>
</section>
    <section class="main_section_area_about">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-12 col-md-8 col-lg-6 col-xxl-5">
            <div class="text-center mb-8 mb-lg-18 px-xl-9 px-xxl-7">
              <h2 class="font-size-9 mb-6">Ipsum dolor</h2>
              <p class="font-size-4 text-default-color px-xs-9 px-md-0">Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui nesciunt nemo reprehenderit quidem repellendus ad animi, vero architecto</p>
            </div>
          </div>
        </div>
        <div class="row justify-content-center" data-aos="fade-up" data-aos-duration="800" data-aos-once="true">
          <div class="col-xl-4 col-lg-6 col-md-6 col-sm-11 mb-9">
            <!-- Single Featured Job -->
            <div class="pt-9 px-xl-9 px-lg-7 px-7 pb-7 light-mode-texts bg-white rounded hover-shadow-3">
              <div class="media align-items-center">
                <div class="square-52 bg-pink mr-8 rounded">
                  <a href="#"><img src="image/svg/icon-leaf.svg" alt=""></a>
                </div>
                <div>
                  <a href="#" class="font-size-3 text-default-color line-height-2">Leaf.co</a>
                  <h3 class="font-size-6 mb-0"><a class="heading-default-color font-weight-semibold" href="#">Full-Stack Developer</a></h3>
                </div>
              </div>
              <div class="d-flex pt-17">
                <ul class="list-unstyled mb-1 d-flex flex-wrap">
                  <li>
                    <a href="#" class="bg-regent-opacity-15 text-denim font-size-3 rounded-3 min-width-px-100 px-3 flex-all-center mr-6 h-px-33 mt-4">
                      <i class="icon icon-pin-3 mr-2 font-weight-bold"></i> New York
                    </a>
                  </li>
                  <li>
                    <a href="#" class="bg-regent-opacity-15 text-orange font-size-3 rounded-3 min-width-px-100 px-3 flex-all-center mr-6 h-px-33 mt-4">
                      <i class="fa fa-briefcase mr-2 font-weight-bold"></i> Full-time
                    </a>
                  </li>
                </ul>
                <a href="javascript:" class="bookmark-button toggle-item font-size-6 ml-auto line-height-reset px-0 mt-6 text-default-color  clicked  ">
                </a>
              </div>
            </div>
            <!-- End Single Featured Job -->
          </div>
          <div class="col-xl-4 col-lg-6 col-md-6 col-sm-11 mb-9">
            <!-- Single Featured Job -->
            <div class="pt-9 px-xl-9 px-lg-7 px-7 pb-7 light-mode-texts bg-white rounded hover-shadow-3">
              <div class="media align-items-center">
                <div class="square-52 bg-indigo mr-8 rounded">
                  <a href="#"><img src="image/svg/text-Fimize.html" alt=""></a>
                </div>
                <div>
                  <a href="#" class="font-size-3 text-default-color line-height-2">Fimize</a>
                  <h3 class="font-size-6 mb-0"><a class="heading-default-color font-weight-semibold" href="#">Senior Marketing Expert</a></h3>
                </div>
              </div>
              <div class="d-flex pt-17">
                <ul class="list-unstyled mb-1 d-flex flex-wrap">
                  <li>
                    <a href="#" class="bg-regent-opacity-15 text-denim font-size-3 rounded-3 min-width-px-100 px-3 flex-all-center mr-6 h-px-33 mt-4">
                      <i class="icon icon-pin-3 mr-2 font-weight-bold"></i> London
                    </a>
                  </li>
                  <li>
                    <a href="#" class="bg-regent-opacity-15 text-orange font-size-3 rounded-3 min-width-px-100 px-3 flex-all-center mr-6 h-px-33 mt-4">
                      <i class="fa fa-briefcase mr-2 font-weight-bold"></i> Full-time
                    </a>
                  </li>
                </ul>
                <a href="javascript:" class="bookmark-button toggle-item font-size-6 ml-auto line-height-reset px-0 mt-6 text-default-color  ">
                </a>
              </div>
            </div>
            <!-- End Single Featured Job -->
          </div>
          <div class="col-xl-4 col-lg-6 col-md-6 col-sm-11 mb-9">
            <!-- Single Featured Job -->
            <div class="pt-9 px-xl-9 px-lg-7 px-7 pb-7 light-mode-texts bg-white rounded hover-shadow-3">
              <div class="media align-items-center">
                <div class="square-52 bg-regent mr-8 rounded">
                  <a href="#"><img src="image/svg/icon-shark-2.svg" alt=""></a>
                </div>
                <div>
                  <a href="#" class="font-size-3 text-default-color line-height-2">Shark</a>
                  <h3 class="font-size-6 mb-0"><a class="heading-default-color font-weight-semibold" href="#">3D Artist</a></h3>
                </div>
              </div>
              <div class="d-flex pt-17">
                <ul class="list-unstyled mb-1 d-flex flex-wrap">
                  <li>
                    <a href="#" class="bg-regent-opacity-15 text-denim font-size-3 rounded-3 min-width-px-100 px-3 flex-all-center mr-6 h-px-33 mt-4">
                      <i class="icon icon-pin-3 mr-2 font-weight-bold"></i> California
                    </a>
                  </li>
                  <li>
                    <a href="#" class="bg-regent-opacity-15 text-orange font-size-3 rounded-3 min-width-px-100 px-3 flex-all-center mr-6 h-px-33 mt-4">
                      <i class="fa fa-briefcase mr-2 font-weight-bold"></i> Remote
                    </a>
                  </li>
                </ul>
                <a href="javascript:" class="bookmark-button toggle-item font-size-6 ml-auto line-height-reset px-0 mt-6 text-default-color  ">
                </a>
              </div>
            </div>
            <!-- End Single Featured Job -->
          </div>
          <div class="col-xl-4 col-lg-6 col-md-6 col-sm-11 mb-9">
            <!-- Single Featured Job -->
            <div class="pt-9 px-xl-9 px-lg-7 px-7 pb-7 light-mode-texts bg-white rounded hover-shadow-3">
              <div class="media align-items-center">
                <div class="square-52 bg-yellow-2 mr-8 rounded">
                  <a href="#"><img src="image/svg/text-K.svg" alt=""></a>
                </div>
                <div>
                  <a href="#" class="font-size-3 text-default-color line-height-2">Klara</a>
                  <h3 class="font-size-6 mb-0"><a class="heading-default-color font-weight-semibold" href="#">Content Marketing Lead</a></h3>
                </div>
              </div>
              <div class="d-flex pt-17">
                <ul class="list-unstyled mb-1 d-flex flex-wrap">
                  <li>
                    <a href="#" class="bg-regent-opacity-15 text-denim font-size-3 rounded-3 min-width-px-100 px-3 flex-all-center mr-6 h-px-33 mt-4">
                      <i class="icon icon-pin-3 mr-2 font-weight-bold"></i> Berlin
                    </a>
                  </li>
                  <li>
                    <a href="#" class="bg-regent-opacity-15 text-orange font-size-3 rounded-3 min-width-px-100 px-3 flex-all-center mr-6 h-px-33 mt-4">
                      <i class="fa fa-briefcase mr-2 font-weight-bold"></i> Full-time
                    </a>
                  </li>
                </ul>
                <a href="javascript:" class="bookmark-button toggle-item font-size-6 ml-auto line-height-reset px-0 mt-6 text-default-color  ">
                </a>
              </div>
            </div>
            <!-- End Single Featured Job -->
          </div>
          <div class="col-xl-4 col-lg-6 col-md-6 col-sm-11 mb-9">
            <!-- Single Featured Job -->
            <div class="pt-9 px-xl-9 px-lg-7 px-7 pb-7 light-mode-texts bg-white rounded hover-shadow-3">
              <div class="media align-items-center">
                <div class="square-52 bg-orange-2 mr-8 rounded">
                  <a href="#"><img src="image/svg/icon-thunder.svg" alt=""></a>
                </div>
                <div>
                  <a href="#" class="font-size-3 text-default-color line-height-2">Thunder</a>
                  <h3 class="font-size-6 mb-0"><a class="heading-default-color font-weight-semibold" href="#">Product Manager</a></h3>
                </div>
              </div>
              <div class="d-flex pt-17">
                <ul class="list-unstyled mb-1 d-flex flex-wrap">
                  <li>
                    <a href="#" class="bg-regent-opacity-15 text-denim font-size-3 rounded-3 min-width-px-100 px-3 flex-all-center mr-6 h-px-33 mt-4">
                      <i class="icon icon-pin-3 mr-2 font-weight-bold"></i> Berlin
                    </a>
                  </li>
                  <li>
                    <a href="#" class="bg-regent-opacity-15 text-orange font-size-3 rounded-3 min-width-px-100 px-3 flex-all-center mr-6 h-px-33 mt-4">
                      <i class="fa fa-briefcase mr-2 font-weight-bold"></i> Full-time
                    </a>
                  </li>
                </ul>
                <a href="javascript:" class="bookmark-button toggle-item font-size-6 ml-auto line-height-reset px-0 mt-6 text-default-color  ">
                </a>
              </div>
            </div>
            <!-- End Single Featured Job -->
          </div>
          <div class="col-xl-4 col-lg-6 col-md-6 col-sm-11 mb-9">
            <!-- Single Featured Job -->
            <div class="pt-9 px-xl-9 px-lg-7 px-7 pb-7 light-mode-texts bg-white rounded hover-shadow-3">
              <div class="media align-items-center">
                <div class="square-52 bg-helio mr-8 rounded">
                  <a href="#"><img src="image/svg/text-asios.svg" alt=""></a>
                </div>
                <div>
                  <a href="#" class="font-size-3 text-default-color line-height-2">Shark</a>
                  <h3 class="font-size-6 mb-0"><a class="heading-default-color font-weight-semibold" href="#">Front-end Developer</a></h3>
                </div>
              </div>
              <div class="d-flex pt-17">
                <ul class="list-unstyled mb-1 d-flex flex-wrap">
                  <li>
                    <a href="#" class="bg-regent-opacity-15 text-denim font-size-3 rounded-3 min-width-px-100 px-3 flex-all-center mr-6 h-px-33 mt-4">
                      <i class="icon icon-pin-3 mr-2 font-weight-bold"></i> New York
                    </a>
                  </li>
                  <li>
                    <a href="#" class="bg-regent-opacity-15 text-orange font-size-3 rounded-3 min-width-px-100 px-3 flex-all-center mr-6 h-px-33 mt-4">
                      <i class="fa fa-briefcase mr-2 font-weight-bold"></i> Full-time
                    </a>
                  </li>
                </ul>
                <a href="javascript:" class="bookmark-button toggle-item font-size-6 ml-auto line-height-reset px-0 mt-6 text-default-color  ">
                </a>
              </div>
            </div>
            <!-- End Single Featured Job -->
          </div>
        </div>
        <div class="row">
          <div class="col-12 text-center pt-md-11 ">
            <a class="text-green font-weight-bold text-uppercase font-size-3" href="index.php">Find More Jobs <i class="fas fa-arrow-right ml-3"></i>
            </a>
          </div>
        </div>
      </div>
</section>
    <section class="pt-13 pt-lg-30 pb-lg-30 main_section_area_about">
      <div class="container">
        <div class="row align-items-center justify-content-center">
          <div class="col-xl-6 col-lg-6 col-md-8 col-xs-10" data-aos="fade-right" data-aos-duration="800" data-aos-once="true">
            <div class="position-relative px-xl-20 pr-md-15 pr-9">
              <img src="image/l3/png/content-1-img1.png" alt="" class="w-100 rounded-4" />
              <div class="abs-content pos-abs-br mb-30 mr-8 rounded-4 rotate-n10 border-10 border-white shadow-2">
                <img src="image/l3/png/content-1-img2.png" alt="" class="rounded-4 border-white border-width-3">
              </div>
            </div>
          </div>
          <div class="col-xxl-5 col-xl-6 col-lg-6 col-md-8 col-sm-11" data-aos="fade-left" data-aos-duration="800" data-aos-once="true">
            <div class="content-2 pl-xl-10 d-flex flex-column justify-content-center h-100 pt-lg-0 pt-15 pr-xl-10 pr-xxl-0">
              <h2 class="font-size-8 mb-7 pr-xs-13  pr-md-0 pr-sm-8">
                Lorem <span class="text-green">50k+ people</span>  ipsum dolor sit amet  elit.
              </h2>
              <p class="text-default-color font-size-5 mb-7 mb-lg-12 pr-xxl-13 pr-lg-0 pr-md-10">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui nesciunt nemo reprehenderit quidem repellendus ad animi,
              </p>
              <a class="text-green font-weight-bold text-uppercase font-size-3" href="#">Learn More <i class="fas fa-arrow-right ml-3"></i></a>
              <div class="media mb-9 mt-9 mt-lg-15 pr-sm-10 pr-md-18 pr-xl-20">
                <div class="media-img">
                  <img src="image/l3/png/media-img1.png" alt="" class="circle-48">
                </div>
                <div class="media-body pl-7">
                  <p class="mb-0 font-size-4 heading-default-color mb-7">“Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui nesciunt nemo reprehenderit quidem repellendus ad animi,”</p>
                  <h6 class="mb-0 font-size-4">Davis Jones</h6>
                  <p class="font-size-3 text-default-color">Full-Stack Developer</p>
                </div>>
              </div>
            </div>
            
          </div>
        </div>
      </div>
    </section>
    <section class="pb-lg-24 pb-13 main_section_area_about">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-xxl-5 col-xl-6 col-lg-6 col-md-8 col-sm-10 order-2 order-lg-1" data-aos="fade-right" data-aos-duration="800" data-aos-once="true">
            <div class="position-relative d-flex flex-column justify-content-center h-100 pr-xl-8 pr-0 mt-5 mt-lg-0">
              <h2 class="font-size-8 mb-7 pr-xs-13  pr-md-0 pr-sm-8">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. 
              </h2>
              <p class="text-default-color font-size-5 mb-7 mb-lg-12 pr-xxl-13 pr-lg-0 pr-md-10">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui nesciunt nemo reprehenderit quidem repellendus ad              </p>
              <a class="text-green font-weight-bold text-uppercase font-size-3" href="#">Learn More <i class="fas fa-arrow-right ml-3"></i>
              </a>
            </div>
          </div>
          <div class="col-lg-6 col-md-8 order-1 order-lg-2" data-aos="fade-left" data-aos-duration="800" data-aos-once="true">
            <div class="pl-lg-10 pl-0">
              <div class="d-flex  mx-sm-n3">
                <div class="d-flex flex-column px-3 px-sm-6 w-lg-auto w-100">
                  <img src="image/l3/png/content-2-img1.png" alt="" data-aos="zoom-in" data-aos-duration="500" data-aos-once="true" class="w-100 pb-6 pb-sm-9 rounded-4 aos-init aos-animate">
                  <img src="image/l3/png/content-2-img2.png" alt="" data-aos="zoom-in" data-aos-duration="500" data-aos-delay="700" data-aos-once="true" class="w-100 pb-6 pb-sm-9 rounded-4 aos-init aos-animate">
                </div>
                <div class="d-flex flex-column pt-xs-11 px-3 px-sm-6 w-lg-auto w-100">
                  <img src="image/l3/png/content-2-img3.png" alt="" data-aos="zoom-in" data-aos-duration="500" data-aos-delay="400" data-aos-once="true" class="w-100 pb-6 pb-sm-9 rounded-4 aos-init aos-animate">
                  <div class="bg-green py-16 px-19 rounded-4"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    


      <!-- +++++++++++++  footer +++++++++++ -->
      <?php include 'includes/footer.php' ?>
      <!-- +++++++++++++ footer +++++++++++++++++ -->
      <script src="assets/jquery/jquery.js"></script>
      <script src="plugins/fancybox/jquery.fancybox.min.js"></script>
      <script src="plugins/nice-select/jquery.nice-select.min.js"></script>
      <script src="plugins/aos/aos.min.js"></script>
      <script src="plugins/slick/slick.min.js"></script>
      <script src="plugins/counter-up/jquery.counterup.min.js"></script>
      <script src="plugins/counter-up/jquery.waypoints.min.js"></script>
      <script src="plugins/ui-range-slider/jquery-ui.js"></script>
      <script src="js/custom.js"></script>
      <script>

      </script>
   </body>
</html>