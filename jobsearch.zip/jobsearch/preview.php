<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>

<input id="get_hidden_val" type="hidden" value="1" name="">
<button id="add_row">Add</button>

<hr>

<table width="100%"  cellspacing="0" cellpadding="2px">
	<thead>
		<tr>
			<th>S. No.</th>
			<th>Product Name</th>
			<th>QTY</th>
			<th>Unit Price </th>
			<th>Total Price</th>
			<th>Additional Price</th>
			<th>Delete</th>
		</tr>
	</thead>
	<tbody id="set_data">
		
	</tbody>
</table>

<div class="total_o">
	<table>
		<thead>
			<tr>
				<td>Total QTY</td>
				<td><div id="tatl_a_o">0</div><input id="tatl_a" type="hidden" name="" value="" ></td>
			</tr>
			<tr>
				<td>Aditional Charges</td>
				<td><div id="tatl_b_o">0</div><input id="tatl_b" type="hidden" name="" value="" disabled></td>
			</tr>
			<tr>
				<td>Total Price</td>
				<td><div id="tatl_c_o">0</div><input id="tatl_c" type="hidden" name="" value="" disabled></td>
			</tr>
		</thead>
	</table>
</div>

<script src="assets/jquery/jquery.js"></script>
<script type="text/javascript">
	function get_data() {
		$.ajax({
			url: 'delete_fetch.php',
			type: 'POST',
			success: function (data) {
				$('#set_data').html(data);
			}
		})
	}
	get_data();

	$('#add_row').click(function () {
		var option = $('#get_hidden_val').val();
		$.ajax({
			url: 'delete_insert.php',
			type: 'POST',
			data: {option_key:option},
			success: function (data) {
				if (data == 0) {
					get_data();
					get_count_of_totalPrice();
					get_count_of_additionalCharges();
                    get_count_of_qty();
                    calculation();
				}
			}
		})
	});

	function get_count_of_totalPrice() {
		$.ajax({
			url: 'get_count_all.php',
			type: 'POST',
			success: function (data) {
				//$('#tatl_c').attr('value',data);
				$('#tatl_c_o').html(data);
			}
		})
	}
	get_count_of_totalPrice();

	function get_count_of_additionalCharges() {
		$.ajax({
			url: 'get_count_all_addition.php',
			type: 'POST',
			success: function (data) {
				//$('#tatl_b').attr('value',data);
				$('#tatl_b_o').html(data);
			}
		})
	}
	get_count_of_additionalCharges();

	function get_count_of_qty() {
		$.ajax({
			url: 'get_count_all_qty.php',
			type: 'POST',
			success: function (data) {
				//$('#tatl_a').attr('value',data);
				$('#tatl_a_o').html(data);
			}
		})
	}
	get_count_of_qty();

	function calculation() {
		var val_one = $('#tatl_a').val();
		var val_two = $('#tatl_b').val();
		var val_three = $('#tatl_c').val();
		var val_qty = val_one * val_three;
		var val_addition = val_one * val_two;
		var total = val_qty + val_addition;
		$('#tatl_a_o').html(val_one);
		$('#tatl_b_o').html(val_two);
		$('#tatl_c_o').html(total);
	}

	calculation();
	// var val_four = $(this).closest('tbody tr').find("input[name='ptotal']").val();
	$(document).on('blur','#name',function () {
		var val_one = $(this).closest('tbody tr').find("input[name='pname']").val();
		var val_two = $(this).closest('tbody tr').find("input[name='pqty']").val();
		var val_three = $(this).closest('tbody tr').find("input[name='punit']").val();
		var val_five = $(this).closest('tbody tr').find("input[name='paddition']").val();
		var val_unq = $(this).data('name');
		var val_fivee = parseInt(val_five);
		var get_total_price = val_two * val_three;
		//alert(get_total_price);
		// alert(val_one + '|'+ val_two +'|'+val_three +'|'+val_four +'|'+val_unq+'|'+val_five);
		$.ajax({
			url: 'delete_update.php',
			type: 'POST',
			data: { pname_key:val_one,
					pqty_key:val_two,
					punit_key:val_three,
					paddition_key:val_fivee,
					get_total_price_key: get_total_price,
					val_unq_key: val_unq
				   },
			success: function (data) {
				if (data == 0) {
					get_data();
					get_count_of_totalPrice();
					get_count_of_additionalCharges();
                    get_count_of_qty();
                    calculation();
				}
			}
		})
	})

	$(document).on('click','#delete_btn',function () {
		var get_delete_id = $(this).data('deletebtn');
		$.ajax({
			url: 'delete_delete.php',
			type: 'POST',
			data: {get_delete_key:get_delete_id},
			success: function (data) {
				if (data == 0) {
					get_data();
					get_count_of_totalPrice();
					get_count_of_additionalCharges();
                    get_count_of_qty();
                    calculation();
				}
			}
		})
	})

	
	
	
    
// last_name
// option_gen
// UPDATE `option_table` SET `option_id`='[value-1]',`option_name`='[value-2]',`option_last`='[value-3]',`option_gender`='[value-4]',`option_group`='[value-5]' WHERE 1
</script>
</body>
</html>