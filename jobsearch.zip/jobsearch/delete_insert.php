<?php  
include 'includes/config.php';
$get_data = mysqli_real_escape_string($conn , $_POST['option_key']);

$sql = "INSERT INTO `option_table`(`product_name`, `qty`, `unit_price`, `total_price`, `additional_price`) VALUES ('','$get_data','','','')";

$result = mysqli_query($conn , $sql) or die();
if ($result) {
	echo "0";
} else {
	echo "1";
}
?>