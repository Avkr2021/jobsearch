<?php  
include 'includes/config.php';
$pname_key = mysqli_real_escape_string($conn , $_POST['pname_key']);
$pqty_key = mysqli_real_escape_string($conn , $_POST['pqty_key']);
$punit_key = mysqli_real_escape_string($conn , $_POST['punit_key']);
$ptotal_key = mysqli_real_escape_string($conn , $_POST['get_total_price_key']);
$paddition_key = mysqli_real_escape_string($conn , $_POST['paddition_key']);
$unq_id = $_POST['val_unq_key'];
//echo $pname_key . $pqty_key . $punit_key . $ptotal_key . $paddition_key . $unq_id;

$sql = "UPDATE `option_table` SET `product_name`='$pname_key',`qty`='$pqty_key',`unit_price`='$punit_key',`total_price`='$ptotal_key',`additional_price`='$paddition_key' WHERE product_id ='$unq_id'";
$result = mysqli_query($conn , $sql) or die();
if ($result) {
	echo "0";
} else {
	echo "1";
}


?>