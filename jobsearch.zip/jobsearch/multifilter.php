<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <meta name="robots" content="noindex" />
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
      <link rel="stylesheet" href="assets/css/style.css">
      <!-- <link rel="shortcut icon" href="image/favicon.png" type="image/x-icon"> -->
      <!-- Bootstrap , fonts & icons  -->
      <link rel="stylesheet" href="css/bootstrap.css">
      <link rel="stylesheet" href="fonts/icon-font/css/style.css">
      <link rel="stylesheet" href="fonts/typography-font/typo.css">
      <link rel="stylesheet" href="fonts/fontawesome-5/css/all.css">
      <!-- Plugin'stylesheets  -->
      <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
      <!-- Vendor stylesheets  -->
      <link rel="stylesheet" href="css/main.css">
      <!-- Custom stylesheet -->
      <title>Admin</title>
    
</head>
<body>

<div class="outer_box">
   <!-- header admin -->
   <?php include 'includes/new_admin_header.php' ?>
   <!-- header admin -->
   <div class="main_dashboard_area_outer">
      <!-- nav admin -->
      <?php include 'includes/new_admin_nav.php' ?>
      <!-- nav admin -->
      <div id="cm_4_id" class="cm_3 main_dashboard_inner_two w70">
         <!-- +++++++++++++++++++++ tab one ++++++++++++++++++++++ -->
         <div id="city_loader" class="cm_admin tabPanel">
            <div class="change_in_website add_product">
               <h4 class="mb-0">Applicants Advance Search</h4>
               <!-- <div class="search_bar_applicants">
                  <input id="search_applicants" type="text" placeholder="Search">
               </div> -->
               <div class="filter_product multifilter_main">
                  <input class="form-control range_picker" type="text" name="daterange" />
               </div>
            </div>
            <div class="multiple_filter multifilter_main">
              <table class="table" width="100%">
                <thead>
                  <tr class="filters">
                    <th>Job Title
                      <select id="jobTitle-filter" disabled class="form-control">
                      </select>
                    </th>
                    <th>Gender
                      <select id="gender-filter" disabled class="form-control">
                        <option>None</option>
                        <option>Male</option>
                        <option>Female</option>
                      </select>
                    </th>
                    <th>Job Location
                      <select id="location-filter" disabled class="form-control">
                        <option>Any</option>
                        <option>Gurgaon</option>
                        <option>Delhi</option>
                        <option>Noida</option>
                      </select>
                    </th>
                    <th>Communication
                      <select id="english-filter" disabled class="form-control">
                        <option>None</option>
                        <option>Excilent</option>
                        <option>Average</option>
                        <option>Good</option>
                      </select>
                    </th>
                  </tr>
                </thead>
              </table>
            </div>
            <div class="details_author details_author_new main_tab_webv">
               <table id="task-list-tbl" width="100%" border="1px">
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Applied for</th>
                      <th>job Location</th>
                      <th>Age</th>
                      <th>Gender</th>
                      <th>Communication</th>
                      <th>Email</th>
                      <th>Mobile</th>
                      <th>Date</th>
                      <th>Experience</th>
                      <th>Location</th>
                      <th class="text-center">PDF</th>
                    </tr>
                  </thead>
                  <tbody id="set_data">

                  </tbody>
                </table>
            </div>
            <div style="height: 20px;"></div>
            <!-- ooooo -->
            <div class="pdf_viewer" id="scroller_pdf">
               <iframe class="pdf_viewer_iframe" name="myiframe" id="myiframe" src=""></iframe>
           </div>
            <!-- ooooo -->
         </div>
         <!-- +++++++++++++++++++++ tab one ++++++++++++++++++++++ -->
      </div>
   </div>
</div>
<!-- +++++++++++++++ Put your all code before this line ++++++++++++ -->
<!-- +++++++++++++++++++ code end +++++++++++++++++ -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/jquery/jquery.js"></script>
<script src="js/custom.js"></script>
<!-- date range picker -->
<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
<script type="text/javascript">
  var
  filters = {
    user: null,
    status: null,
    milestone: null,
    priority: null,
    tags: null
  };

function updateFilters() {
  $('.task-list-row').hide().filter(function() {
    var
      self = $(this),
      result = true; // not guilty until proven guilty
    
    Object.keys(filters).forEach(function (filter) {
      if (filters[filter] && (filters[filter] != 'None') && (filters[filter] != 'Any')) {
        result = result && filters[filter] === self.data(filter);
      }
    });

    return result;
  }).show();
}

function changeFilter(filterName) {
  filters[filterName] = this.value;
  updateFilters();
}

$('#jobTitle-filter').on('change', function() {
  changeFilter.call(this, 'jobtitle');
});

$('#gender-filter').on('change', function() {
  changeFilter.call(this, 'gender');
});

$('#location-filter').on('change', function() {
  changeFilter.call(this, 'location');
});

$('#english-filter').on('change', function() {
  changeFilter.call(this, 'english');
});


//future use for a text input filter
// $('#search').on('click', function() {
//     $('.box').hide().filter(function() {
//         return $(this).data('order-number') == $('#search-criteria').val().trim();
//     }).show();
// });
</script>

<script type="text/javascript">
  function get_job_title() {
     $.ajax({
          url: 'ajaxfils/get_job_title_adv.php',
          type: 'POST',
          success: function (data) {
             $('#jobTitle-filter').html(data);
          }
      })
  }

  get_job_title();

  function get_location_job() {
    $.ajax({
          url: 'ajaxfils/get_city_for_advance.php',
          type: 'POST',
          success: function (data) {
             $('#location-filter').html(data);
          }
      })
  }
  get_location_job();

// based on date range picker ++++++++++++++++++++++

$(function() {
  $('input[name="daterange"]').daterangepicker({
    opens: 'left'
  }, function(start, end, label) {
    var start = start.format('DD/MM/YYYY');
    var end = end.format('DD/MM/YYYY');
    $.ajax({
          url: 'ajaxfils/new_multifilter_ajax.php',
          type: 'POST',
          data: {start_key: start, end_key: end},
          success: function (data) {
             $('#set_data').html(data);
              
          }
      }).done((response)=> {
        $('.filters select').removeAttr("disabled")
     });
  })
});

//pdf viewer ------------------

$(document).on('click','#file_btn_view',function () {
    var pdf_id = $(this).data('pdf-id');
    $('#myiframe').attr('src','applicant_pdf/'+pdf_id);
    $('#scroller_pdf').show();
    $('#pdf_overlay_id').show();
})

$('#scroller_pdf').before("<div id='pdf_overlay_id' class='pdf_overlay'></div>");
    $('#pdf_overlay_id').click(function () {
    $('#pdf_overlay_id').hide();
    $('#scroller_pdf').hide();
})

</script>
</body>
</html>