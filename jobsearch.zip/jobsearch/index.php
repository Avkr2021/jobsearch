<!doctype html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <meta name="robots" content="noindex" />
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
      <link rel="stylesheet" href="assets/css/style.css">
      <!-- <link rel="shortcut icon" href="image/favicon.png" type="image/x-icon"> -->
      <!-- Bootstrap , fonts & icons  -->
      <link rel="stylesheet" href="css/bootstrap.css">
      <link rel="stylesheet" href="fonts/icon-font/css/style.css">
      <link rel="stylesheet" href="fonts/typography-font/typo.css">
      <link rel="stylesheet" href="fonts/fontawesome-5/css/all.css">
      <!-- Plugin'stylesheets  -->
      <link rel="stylesheet" href="plugins/fancybox/jquery.fancybox.min.css">
      <link rel="stylesheet" href="plugins/nice-select/nice-select.min.css">
      <link rel="stylesheet" href="plugins/slick/slick.min.css">
      <link rel="stylesheet" href="plugins/ui-range-slider/jquery-ui.css">
      <!-- Vendor stylesheets  -->
      <link rel="stylesheet" href="css/main.css">
      <!-- Custom stylesheet -->
      <title>Developer Testing</title>
   </head>
   <body>
      <section class="manin_ul_areaX">
         <?php include 'includes/navbar.php' ?>
         <!-- +++++++++++++  header end +++++++++++ -->
         <div class="important_message">
            <div><label>We do not charge anything <br> from the Candidates</label></div>
         </div>
         <div class="inner_main_containerX">
            <div class="container">
               <div class="row mt-14 mb-5">
                  <div class="col-md-8 m-auto">
                     <div class="">
                       <!-- search-form -->
                       <form action="" class="search-form new_border_css">
                         <div class="filter-search-form-1 bg-white rounded-sm shadow-4">
                           <div class="filter-inputs">
                             <div class="form-group position-relative">
                               <input class="form-control focus-reset pl-13" type="text" id="keyword" placeholder="Job title">
                               <span class="h-100 w-px-50 pos-abs-tl d-flex align-items-center justify-content-center font-size-6"><i class="icon icon-zoom-2 text-primary font-weight-bold"></i></span>
                             </div>
                             <!-- .select-city starts -->
                             <div class="form-group position-relative">
                               <select name="country" id="country" class="index_contry_search pl-13 h-100 arrow-3 font-size-4">
                                 
                               </select>
                               <span class="h-100 w-px-50 pos-abs-tl d-flex align-items-center justify-content-center font-size-6"><i class="icon icon-pin-3 text-primary font-weight-bold"></i></span>
                             </div>
                             <!-- ./select-city ends -->
                           </div>
                           <!-- .Hero Button -->
                           <div class="button-block hide_on_mobile">
                             <button class="btn btn-primary line-height-reset h-100 btn-submit w-100 text-uppercase">Search</button>
                           </div>
                           <!-- ./Hero Button -->
                         </div>
                       </form>
                       <!-- ./search-form -->
                       <p class="heading-default-color font-size-3 pt-7"><span class="text-smoke">Search keywords e.g.</span> Product Designer</p>
                     </div>
                  </div>
               </div>
               <div class="row">
                  <div id="get_job_data" class="col-md-6">
                     <!-- ++++++++++++++++++++ add job card +++++++++++++++++++++ -->

                     <!-- ++++++++++++++++++++ add job card +++++++++++++++++++++ -->
                  </div>
                  <div class="col-md-6 web_view">
                     <div id="insert_dynamic_data" class="set_scroll setscroll_border">
                        <div class="search_img_icon_parent">
                           <img src="assets/img/find2.svg" alt="" class="search_img_icon">
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- mobile job details -->
      <div id="show_mobile_popup" class="popup_job_details">
         <div class="cut_mobile">
            <i id="hide_mobile_voiew" class="bi bi-x-circle"></i>
         </div>
         <div class="inner_popup">
            <div id="insert_dynamic_mobile" class="set_scroll setscroll_border">
            </div>
         </div>
      </div>
      <!-- mobile job details -->
      <!-- signup popup --><!--  -->
      <div id="sign_up_modal" oncontextmenu="return false;" class="popup_cls" style="display:none;">
         <div class="mobile_content_signup_area ">
            <div class="outer_lighthouse">
               <div class="image_lighthouse">
                  <img src="assets/img/signup.svg" class="light_house_image">
                  <p class="text-center continue_text">Enter Your name and mobile number to continue</p>
               </div>
               <form class="usre_data_form">
                  <input class="form-control" id="sign_up_name_user" type="text" placeholder="Your Name">
                  <input class="form-control" id="sign_up_mobile_user" type="text" placeholder="Your Mobile No.">
                  <button id="submit_user_data" class="procced_ahed_signup"><i class="bi_shadow bi bi-arrow-right-circle-fill"></i></button>
               </form>
            </div>
         </div>
      </div>
      <!-- signup popup end -->
      <!-- +++++++++++++  footer +++++++++++ -->
      <?php include 'includes/footer.php' ?>
      <!-- +++++++++++++ footer +++++++++++++++++ -->
      <script src="assets/jquery/jquery.js"></script>
      <script src="plugins/fancybox/jquery.fancybox.min.js"></script>
      <script src="plugins/nice-select/jquery.nice-select.min.js"></script>
      <script src="plugins/aos/aos.min.js"></script>
      <script src="plugins/slick/slick.min.js"></script>
      <script src="plugins/counter-up/jquery.counterup.min.js"></script>
      <script src="plugins/counter-up/jquery.waypoints.min.js"></script>
      <script src="plugins/ui-range-slider/jquery-ui.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.0/jquery.cookie.js"></script>
      <script src="js/custom.js"></script>
      <script type="text/javascript">
         // jquery cookies made on first visite -------------

            jQuery(document).ready(function () {
                function openFancybox() {
                    setTimeout(function () {
                        $('#sign_up_modal').show();
                    }, 5000);
                };
                var visited = jQuery.cookie('visited');
                if (visited == 'yes') {
                     // second page load, cookie active
                } else {
                    openFancybox(); // first page load, launch fancybox
                }
                jQuery.cookie('visited', 'yes', {
                    expires: 365 // the number of days cookie  will be effective
                });
            });
      </script>
      <script>

         // ----------------------------------
         function list_of_bullet() {
            $.ajax({
            url: 'ajaxfils/data_from_another.php',
            type: 'POST',
            success: function (data) {
               $('#get_job_data').html(data);
            }
         });
         }
         list_of_bullet();

         $(document).on('click','#job_container', function () {
            var get_job_id = $(this).data('job-id');
            var loader = "<div class='ui-layout__section ui-layout__section--primary'><div class='ui-layout__item'><section class='ui-card reports-index-card'><div class='loading-wrapper'><div class='title-block'><div class='loading title'></div><div class='loading content'></div><div class='loading content last-row'></div></div><div class='title-block'><div class='loading title'></div><div class='loading content'></div><div class='loading content last-row'></div></div><div class='list-block'><div class='loading content line-item'></div><div class='loading content line-item-last'></div></div><div class='title-block'><div class='loading title'></div><div class='loading content'></div><div class='loading content last-row'></div></div><div class='list-block'><div class='loading content line-item'></div><div class='loading content line-item-last'></div></div><div class='title-block'><div class='loading title'></div><div class='loading content'></div><div class='loading content last-row'></div></div></div></section></div></div>";
            $('#insert_dynamic_data').html(loader);
            $.ajax({
               url: 'ajaxfils/get_job_details.php',
               type: 'POST',
               data: {get_job_id_key:get_job_id},
               success: function (data) {
                  $('#insert_dynamic_data').html(data);
                  $.ajax({
                     url: 'ajaxfils/get_preview.php',
                     type: 'POST',
                     data: {get_job_id_bullet_key:get_job_id},
                     success: function (data) {
                        $('#get_bullet_point').append(data);
                     }
                  })
                  $.ajax({
                     url: 'ajaxfils/get_preview_new.php',
                     type: 'POST',
                     data: {get_job_id_bullet_key:get_job_id},
                     success: function (data) {
                        $('#experience_point').append(data);
                     }
                  })
               }
            }).done((response)=> {
               $('#fetch_loder').hide();
            });
         })

         // for mobile view ------------

             if ($(window).width() <= 768) {
               $(document).on('click','#job_container',function () {
                   $('#show_mobile_popup').css('display','flex');
                })
                $('#hide_mobile_voiew').click(function () {
                   $('#show_mobile_popup').css('display','none');
                })
                $(document).on('click','#job_container', function () {
                  var get_job_id = $(this).data('job-id');
                  var loader = "<div class='ui-layout__section ui-layout__section--primary'><div class='ui-layout__item'><section class='ui-card reports-index-card'><div class='loading-wrapper'><div class='title-block'><div class='loading title'></div><div class='loading content'></div><div class='loading content last-row'></div></div><div class='title-block'><div class='loading title'></div><div class='loading content'></div><div class='loading content last-row'></div></div><div class='list-block'><div class='loading content line-item'></div><div class='loading content line-item-last'></div></div><div class='title-block'><div class='loading title'></div><div class='loading content'></div><div class='loading content last-row'></div></div><div class='list-block'><div class='loading content line-item'></div><div class='loading content line-item-last'></div></div><div class='title-block'><div class='loading title'></div><div class='loading content'></div><div class='loading content last-row'></div></div></div></section></div></div>";
                  $('#insert_dynamic_data').html(loader);
                  $.ajax({
                     url: 'ajaxfils/get_job_details_mobile.php',
                     type: 'POST',
                     data: {get_job_id_key:get_job_id},
                     success: function (data) {
                        $('#insert_dynamic_mobile').html(data);
                        $.ajax({
                           url: 'ajaxfils/get_preview_mobile.php',
                           type: 'POST',
                           data: {get_job_id_bullet_key:get_job_id},
                           success: function (data) {
                              $('#get_bullet_point_mobile').append(data);
                           }
                        })
                        $.ajax({
                           url: 'ajaxfils/get_preview_new_mobile.php',
                           type: 'POST',
                           data: {get_job_id_bullet_key:get_job_id},
                           success: function (data) {
                              $('#experience_point_mobile').append(data);
                           }
                        })
                     }
                  }).done((response)=> {
                     $('#fetch_loder').hide();
                  });
               }) 
             }
    

         // get city name --------------

          function ge_city_name() {
            $.ajax({
               url: 'ajaxfils/ge_city_name.php',
               type: 'POST',
               success: function (data) {
                  $('#country').html(data);
                  // alert(data);
               }
            })
          }
          ge_city_name();

          // filter according to city --------------

          $('#country').change(function () {
            var get_city = $(this).val();
            var loader = "<div id='city_loader_hide' class='city_loader'><div class='city_loader_inner'><i class='bi bi-arrow-repeat'></i></div></div>";
            $('#city_loader_hide').html(loader);
            if (get_city !== '0') {
                $.ajax({
               url:'ajaxfils/get_job_details_onCity.php',
               type: 'POST',
               data: {get_city_key: get_city},
               success: function (data) {
                   $('#get_job_data').html(data);
               }
            }).done((response)=> {
                  $('#city_loader_hide').hide();
               });
            } else {
                function load_posted_three() {
                 $.ajax({
                  url: 'ajaxfils/get_job_ShowAllCity.php',
                  type: 'POST',
                  success: function (data) {
                     $('#get_job_data').html(data);
                  }
                 });
              }
              load_posted_three();
            }
            
         })

          $('#keyword').on('keyup' , function () {
            var search_term = $(this).val();
            $.ajax({
               url: "ajaxfils/job_title_search.php",
               type: "POST",
               data: {search: search_term},
               success: function (data) {
                  $('#get_job_data').html(data);
               }
            })
          })

          //  user signup ------------------------
          $('#submit_user_data').click(function (e) {
             e.preventDefault();
             var name = $('#sign_up_name_user').val();
             var mobile = $('#sign_up_mobile_user').val();
             if (name !== '' && mobile !== '') {
               var regx = /^[6-9]\d{9}$/;
                 if(regx.test(mobile)) {
                  $.ajax({
                     url: "ajaxfils/send_user_info.php",
                     type: "POST",
                     data: {name_key: name, mobile_key:mobile},
                     success: function (data) {
                        if (data == 0) {
                           $('#sign_up_modal').fadeOut(100);
                        } else {
                           alert('Error to proceed ahead')
                        }
                     }
                  })
                 } else {
                  alert('Invalid Mobile Number');
                 }
             } else {
               alert("Fields can't be empty");
             }
          })
          

      </script>

   </body>
</html>
