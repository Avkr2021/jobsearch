<!doctype html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <meta name="robots" content="noindex" />
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
      <link rel="stylesheet" href="assets/css/style.css">
      <!-- <link rel="shortcut icon" href="image/favicon.png" type="image/x-icon"> -->
      <!-- Bootstrap , fonts & icons  -->
      <link rel="stylesheet" href="css/bootstrap.css">
      <link rel="stylesheet" href="fonts/icon-font/css/style.css">
      <link rel="stylesheet" href="fonts/typography-font/typo.css">
      <link rel="stylesheet" href="fonts/fontawesome-5/css/all.css">
      <!-- Plugin'stylesheets  -->
      <link rel="stylesheet" href="plugins/fancybox/jquery.fancybox.min.css">
      <link rel="stylesheet" href="plugins/nice-select/nice-select.min.css">
      <link rel="stylesheet" href="plugins/slick/slick.min.css">
      <link rel="stylesheet" href="plugins/ui-range-slider/jquery-ui.css">
      <!-- Vendor stylesheets  -->
      <link rel="stylesheet" href="css/main.css">
      <!-- Custom stylesheet -->
      <title>Developer Testing</title>
      <style>
            
      </style>
   </head>
   <body>
      
      <div class="outer_box">
         <!-- header admin -->
         <?php include 'includes/new_admin_header.php' ?>
         <!-- header admin -->
         <div class="main_dashboard_area_outer">
            <!-- nav admin -->
            <?php include 'includes/new_admin_nav.php' ?>
            <!-- nav admin -->
            <div id="cm_4_id" class="cm_3 main_dashboard_inner_two w70">
               <!-- +++++++++++++++++++++ tab one ++++++++++++++++++++++ -->
               <div class="cm_admin tabPanel">
                  <div class="change_in_website add_product">
                     <h4>Posted Jobs</h4>
                     <div class="search_bar_applicants">
                        <input id="search_applicants_post" type="text" placeholder="Search">
                     </div>
                     <div class="filter_product">
                        <select id="add_city_dropdown_post">
                           
                        </select>
                     </div>
                     <!-- <div>
                        <div>     
                           <button id="add_prdt_id" class="add_btn_new">Add Product</button>
                        </div>
                     </div> -->
                  </div>
                  <div class="details_author details_author_new main_tab_webv">
                     <table border="1" cellpadding="5px" cellspacing="0px" width="100%">
                        <thead>
                           <tr>
                              <th>Job Title</th>
                              <th>Job Location</th>
                              <th>Mobile</th>
                              <th>Job Post Date</th>
                              <th class="text-center">Action</th>
                           </tr>
                        </thead>
                        <tbody id="show_posted_job">
                           
                        </tbody>
                     </table>
                  </div>
                  <div style="height: 20px;"></div>
                  <!-- ooooo --><!-- ooooo -->
               </div>
               <!-- +++++++++++++++++++++ tab one ++++++++++++++++++++++ -->
            </div>
         </div>
         <!-- -------------end---------------- -->
      </div>
      <!-- +++++++++++++++++++ code end +++++++++++++++++ -->
      <script src="assets/jquery/jquery.js"></script>
      <script src="plugins/fancybox/jquery.fancybox.min.js"></script>
      <script src="plugins/nice-select/jquery.nice-select.min.js"></script>
      <script src="plugins/aos/aos.min.js"></script>
      <script src="plugins/slick/slick.min.js"></script>
      <script src="plugins/counter-up/jquery.counterup.min.js"></script>
      <script src="plugins/counter-up/jquery.waypoints.min.js"></script>
      <script src="plugins/ui-range-slider/jquery-ui.js"></script>
      <script src="js/custom.js"></script>
      <script>

           $('#toggle_btn').click(function () {
             $('#cm_3_id').toggleClass('invisible');
             $('#cm_4_id').toggleClass('invisibleTwo');
           });

           function loadPostedJob() {
              $.ajax({
               url: 'ajaxfils/loadPostedJobn.php',
               type: 'POST',
               success: function (data) {
                  $('#show_posted_job').html(data);
               }
              });
           }
           loadPostedJob();

           $(document).on('click','#disable_post',function () {
            if (confirm('Do you really want to disable this job ?')) {
                 var get_disable_id = $(this).data('jobpost');
                 var get_delete_new = this;
                 $.ajax({
                  url: 'ajaxfils/update_disable.php',
                  type: 'POST',
                  data: {get_disable_key: get_disable_id},
                  success: function (data) {
                    if (data == 0) {
                     alert('Successfully Disabled')
                     $(get_delete_new).closest('tr').fadeOut();
                    } else {
                     alert('Faild to disable this job');
                    }
                  }
                 });
               }
            });

           function get_city_name() {
            $.ajax({
               url: 'ajaxfils/get_city_name_posted.php',
               type: 'POST',
               success: function (data) {
                  $('#add_city_dropdown_post').html(data);
               }
            })
          }
          get_city_name();

         $('#search_applicants_post').on('keyup' , function () {
         var search_term = $(this).val();

            $.ajax({
               url: "ajaxfils/posted_live_search.php",
               type: "POST",
               data: {search: search_term},
               success: function (data) {
                  $('#show_posted_job').html(data);
               }
            });
         });

      $('#add_city_dropdown_post').change(function () {
         var get_city = $(this).val();
         var loader = "<div id='city_loader_hide' class='city_loader'><div class='city_loader_inner'><i class='bi bi-arrow-repeat'></i></div></div>";
         $('#city_loader_hide').html(loader);
         if (get_city !== '0') {
             $.ajax({
            url:'ajaxfils/get_filter_city_post.php',
            type: 'POST',
            data: {get_city_key: get_city},
            success: function (data) {
                $('#show_posted_job').html(data);
            }
         }).done((response)=> {
               $('#city_loader_hide').hide();
            });
         } else {
             function load_posted_two() {
              $.ajax({
               url: 'ajaxfils/load_filter_all.php',
               type: 'POST',
               success: function (data) {
                  $('#show_posted_job').html(data);
               }
              });
           }
           load_posted_two();
         }
         
      })
      </script>
      <script type="text/javascript">
         $(function($) {
            let url = window.location.href;
            $('ul.admin_ul li a').each(function() {
              if (this.href === url) {
                $(this).closest('a').addClass('active_nav_admin');
              }
            });
          });
      </script>
   </body>
</html>