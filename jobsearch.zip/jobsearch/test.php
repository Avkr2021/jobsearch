<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<style>
    .popup_cls {
      height: 100vh;
      width: 100%;
      border: 2px solid red;
      position: fixed;
      z-index: 9999;
      left: 0;
      top: 0;
    }
	</style>
</head>
<body>
<div id="sign_up_modal" class="popup_cls" style="display:none;">

</div>


<script src="assets/jquery/jquery.js"></script>
<script src="https://code.jquery.com/jquery-latest.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.0/jquery.cookie.js"></script>
<script type="text/javascript">
	
jQuery(document).ready(function () {
    function openFancybox() {
        setTimeout(function () {
            $('#sign_up_modal').show();
        }, 500);
    };
    var visited = jQuery.cookie('visited');
    if (visited == 'yes') {
         // second page load, cookie active
    } else {
        openFancybox(); // first page load, launch fancybox
    }
    jQuery.cookie('visited', 'yes', {
        expires: 365 // the number of days cookie  will be effective
    });
});

</script>
</body>
</html>