<?php 
include 'includes/config.php';
$get_url_id = $_GET['job-id'];
$sql = "SELECT * FROM `job_post` WHERE job_id='$get_url_id' ";
$result = mysqli_query($conn , $sql);
$title_job = mysqli_fetch_assoc($result);
$name_of_job = $title_job['job_title'];
$admin_job_location = $title_job['job_location'];
?>
<!doctype html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <meta name="robots" content="noindex" />
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
      <link rel="stylesheet" href="assets/css/style.css">
      <!-- <link rel="shortcut icon" href="image/favicon.png" type="image/x-icon"> -->
      <!-- Bootstrap , fonts & icons  -->
      <link rel="stylesheet" href="css/bootstrap.css">
      <link rel="stylesheet" href="fonts/icon-font/css/style.css">
      <link rel="stylesheet" href="fonts/typography-font/typo.css">
      <link rel="stylesheet" href="fonts/fontawesome-5/css/all.css">
      <!-- Plugin'stylesheets  -->
      <link rel="stylesheet" href="plugins/fancybox/jquery.fancybox.min.css">
      <link rel="stylesheet" href="plugins/nice-select/nice-select.min.css">
      <link rel="stylesheet" href="plugins/slick/slick.min.css">
      <link rel="stylesheet" href="plugins/ui-range-slider/jquery-ui.css">
      <!-- Vendor stylesheets  -->
      <link rel="stylesheet" href="css/main.css">
      <!-- Custom stylesheet -->
      <title>Developer Testing</title>
      <style>
      </style>
   </head>
   <body>
      <?php include 'includes/navbar.php' ?>
      <!-- +++++++++++++  header end +++++++++++ -->
      <section>
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="contact-form bg-white apply_form_border_new rounded-4 mt-10 pl-sm-10 pl-4 pr-sm-11 pr-4 pt-8 pb-13">
                     <form id="user_form">
                        <fieldset class="apply_fildset">
                           <div class="row pb-10">
                              <div class="col-12">
                                 <h4 class="form_head_post">Applying for the post of <span class="green_line"><?php echo $name_of_job; ?></span></h4>
                              </div>
                           </div>
                           <input name="hidden_job_name" id="hidden_job_id" type="hidden" value="<?php echo $title_job['job_id']; ?>">
                           <input name="hidden_job_location" type="hidden" value="<?php echo $admin_job_location; ?>">
                           <div class="row mb-xl-1 mb-9">
                              <div class="col-lg-4">
                                 <div class="form-group">
                                    <label for="namedash" class="d-block text-black-2 font-size-4 font-weight-semibold mb-4">Full Name <span class="important_field">*</span></label>
                                    <input type="text" class="form-control h-px-48" name="user_name" id="user_name" placeholder="Diego Trud" required>
                                 </div>
                              </div>
                              <div class="col-lg-4">
                                 <div class="form-group">
                                    <label for="namedash" class="d-block text-black-2 font-size-4 font-weight-semibold mb-4">Email <span class="important_field">*</span></label>
                                    <input type="email" name="user_email" class="form-control h-px-48" id="user_email" placeholder="abc@gmail.com" required>
                                 </div>
                              </div>
                              <div class="col-lg-4">
                                 <div class="form-group">
                                    <label for="namedash" class="d-block text-black-2 font-size-4 font-weight-semibold mb-4">Mobile</label>
                                    <input type="text" name="user_mobile" class="form-control h-px-48" id="user_mobile" placeholder="1234567898" required>
                                 </div>
                              </div>
                              <div class="col-lg-4">
                                 <div class="form-group">
                                    <label for="namedash" class="d-block text-black-2 font-size-4 font-weight-semibold mb-4">Age</label>
                                    <input type="text" name="user_age" class="form-control h-px-48" id="user_age" placeholder="e.g 20" required>
                                 </div>
                              </div>
                              <div class="col-lg-4">
                                 <div class="form-group">
                                    <label for="namedash" class="d-block text-black-2 font-size-4 font-weight-semibold mb-4">How many work experience do you have ?</label>
                                    <input type="text" name="user_experience" class="form-control h-px-48" id="user_experience" placeholder="5 Yers, Month or Fresher">
                                 </div>
                              </div>
                              <div class="col-lg-4">
                                 <div class="form-group">
                                    <label for="namedash" class="d-block text-black-2 font-size-4 font-weight-semibold mb-4">Your Current Salary (Month) </label>
                                    <input name="user_salary" type="text" class="form-control h-px-48" id="user_salary" placeholder="15000" >
                                 </div>
                              </div>
                              <div class="col-lg-4">
                                 <div class="form-group">
                                    <label for="namedash" class="d-block text-black-2 font-size-4 font-weight-semibold mb-4">Your expected Salary (Month)</label>
                                    <input type="text" name="user_asking" class="form-control h-px-48" id="user_asking" placeholder="16000">
                                 </div>
                              </div>
                              <div class="col-lg-4">
                                 <div class="form-group">
                                    <label for="namedash" class="d-block text-black-2 font-size-4 font-weight-semibold mb-4">State</label>
                                    <input type="text" name="user_location" class="form-control h-px-48" id="user_location" placeholder="e.g. Delhi" required>
                                 </div>
                              </div>
                              <div class="col-lg-4">
                                 <div class="form-group">
                                    <label for="namedash" class="d-block text-black-2 font-size-4 font-weight-semibold mb-4">Your Current Location</label>
                                    <input type="text" name="user_location" class="form-control h-px-48" id="user_location" placeholder="e.g. Malviya Nagar" required>
                                 </div>
                              </div>
                              <div class="col-lg-4">
                                 <div class="form-group position-relative">
                                    <label for="address" class="d-block text-black-2 font-size-4 font-weight-semibold mb-4">Communication in English</label>
                                    <select name="user_comunination" id="user_comunination" class="nice-select pl-6 h-px-48 arrow-3 w-100 font-size-4" required>
                                       <option value="">-|- Choose an Option -|-</option>
                                       <option value="Excelent">Excelent</option>
                                       <option value="Good">Good</option>
                                       <option value="Average">Average</option>
                                    </select>
                                    <span class="h-100 w-px-50 pos-abs-tl d-flex align-items-center justify-content-center font-size-6"></span>
                                 </div>
                              </div>
                              <div class="col-lg-4">
                                 <div class="form-group">
                                    <label for="" class="d-block text-black-2 font-size-4 font-weight-semibold mb-4">Gender</label>
                                 </div>
                                 <div class="custom-control custom-radio d-inline-block mr-5">
                                    <input type="radio" value="Male" class="custom-control-input" name="gender" id="genderm" required>
                                    <label class="custom-control-label" for="genderm">Male</label>
                                 </div>
                                 <div class="custom-control custom-radio mb-3 d-inline-block">
                                    <input type="radio" value="Female" class="custom-control-input" name="gender" id="genderf" required>
                                    <label class="custom-control-label" for="genderf">Female</label>
                                 </div>
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-md-3">
                                 <label for="address" class="d-inline-block text-black-2 font-size-4 font-weight-semibold mb-4">Upload Your Resume</label>
                                 <input type="file" name="user_file" class="" id="user_file" required>
                              </div>
                              <div class="col-md-9">
                                 <div>
                                    <button name="user_submit" id="user_submit" class="btn btn-green btn-h-60 text-white min-width-px-210 rounded-5 text-uppercase">Submit</button>
                                 </div>
                              </div>
                           </div>
                        </fieldset>
                     </form>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- +++++++++++++  footer +++++++++++ -->
      <?php include 'includes/footer.php' ?>
      <!-- +++++++++++++ footer +++++++++++++++++ -->
      <script src="assets/jquery/jquery.js"></script>
      <script src="plugins/fancybox/jquery.fancybox.min.js"></script>
      <script src="plugins/nice-select/jquery.nice-select.min.js"></script>
      <!-- <script src="plugins/aos/aos.min.js"></script> -->
      <script src="plugins/slick/slick.min.js"></script>
      <script src="plugins/counter-up/jquery.counterup.min.js"></script>
      <script src="plugins/counter-up/jquery.waypoints.min.js"></script>
      <script src="plugins/ui-range-slider/jquery-ui.js"></script>
      <script src="js/custom.js"></script>
      <script>
         $(document).ready(function () {
           $('#user_form').submit(function (e) {
            e.preventDefault();
            var hidden_job_no = $('#hidden_job_id').val();
            var name = $('#user_name').val();
            var email = $('#user_email').val();
            var mobile = $('#user_mobile').val();
            var age = $('#user_age').val();
            var experience = $('#user_experience').val();
            var salary = $('#user_salary').val();
            var asking = $('#user_asking').val();
            var location = $('#user_location').val();
            var comunication = $('#user_comunination').val();
            var gender = $('input[name = "gender"]:checked').val();
            var file = $('#user_file').val();
            if (name !== '' && email !== '' && mobile !== '' && experience !== '' && salary !== '' && asking !== '' && location !== '' && comunication !== '' && gender !== '' && file !== '' && age !== '') {
               var regx = /^[6-9]\d{9}$/ ;
                 if(regx.test(mobile)) {
                  var formData = new FormData(document.getElementById('user_form'));
                  $.ajax({
                     url: 'ajaxfils/get_applicant_details.php',
                     type: 'POST',
                     data: formData,
                     contentType: false,
                     processData: false,
                     success: function (data) {
                        if (data == 1) {
                           alert('Upload Only PDF file');
                        }
                        if (data == 2) {
                           alert('Failed to Save data please try again');
                        }
                        if (data == 3) {
                           alert('All fields are mandatory');
                        }
                        if (data == 0) {
                           alert('Request has been sent successfully');
                           $('#user_form').trigger('reset');
                           window.location.href = "index.php";
                        }
                     }
                  });
                 } else {
                  alert("Wrong Mobile Number");
                 } 
               } else {
               alert('All Fields Are Required');
            }
           })
         })
      </script>
   </body>
</html>