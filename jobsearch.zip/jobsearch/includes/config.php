<?php  

$conn = mysqli_connect('localhost','root','','itmdb');
if ($conn->connect_error) {
	echo $$conn->connect_error;
}
//  else {
// 	echo "Connected Successfully";
// }
// weblivre_itmdb
?>