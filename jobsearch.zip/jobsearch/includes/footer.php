<footer class="footer bg-ebony-clay dark-mode-texts">
      <div class="container  pt-12 pt-lg-19 pb-10 pb-lg-19">
        <div class="row">
          <div class="col-lg-4 col-sm-6 mb-lg-0 mb-9">
            <!-- <img src="image/logo-main-white.png" alt="" class="footer-logo mb-14"> -->
            <img src="image/logoITM.svg" alt="" class="footer-logo">

            <!-- <h2>ITM</h2> -->
            <div class="media mb-11">
              <img src="image/l1/png/message.png" class="align-self-center mr-3" alt="">
              <div class="media-body pl-5">
                <p class="mb-0 font-size-4 text-white">Contact us at</p>
                <a class="mb-0 font-size-4 font-weight-bold" href="mailto:xyx@yoursite.com">itm.recruitmentservices@gmail.com</a>
              </div>
            </div>
            <div class="social-icons">
              <div class="folow_us">
                <h6>Follow us on:</h6>
              </div>
              <div class="social-menu">
                  <ul>
                      <li><a href="#" target="blank"><i class="fab fa-github"></i></i></a></li>
                      <li><a href="#" target="blank"><i class="fab fa-instagram"></i></a></li>
                      <li><a href="#" target="blank"><i class="fab fa-linkedin-in"></i></a></li>
                      <li><a href="#"><i class="fab fa-codepen" target="blank"></i></a></li>
                  </ul>
              </div>
            </div>
          </div>
          <div class="col-lg-8 col-md-6">
            <div class="row">
              <div class="col-lg-3 col-md-6 col-sm-3 col-xs-6">
                <div class="footer-widget widget2 mb-md-0 mb-13">
                  <p class="widget-title font-size-4 text-gray mb-md-8 mb-7">Company</p>
                  <ul class="widget-links pl-0 list-unstyled list-hover-primary">
                    <li class="mb-6"><a class="heading-default-color font-size-4 font-weight-normal" href="#">About us</a></li>
                    <li class="mb-6"><a class="heading-default-color font-size-4 font-weight-normal" href="#">Contact us</a></li>
                    <li class="mb-6"><a class="heading-default-color font-size-4 font-weight-normal" href="#">Careers</a></li>
                    <li class="mb-6"><a class="heading-default-color font-size-4 font-weight-normal" href="#">Press</a></li>
                  </ul>
                  <!-- widget social menu end -->
                </div>
              </div>
              <div class="col-lg-3 col-md-6 col-sm-3 col-xs-6">
                <div class="footer-widget widget4 mb-sm-0 mb-13">
                  <p class="widget-title font-size-4 text-gray mb-md-8 mb-7">Services</p>
                  <ul class="widget-links pl-0 list-unstyled list-hover-primary">
                    <li class="mb-6"><a class="heading-default-color font-size-4 font-weight-normal" href="#">Digital Marketing</a></li>
                    <li class="mb-6"><a class="heading-default-color font-size-4 font-weight-normal" href="#">SEO for Business</a></li>
                    <li class="mb-6"><a class="heading-default-color font-size-4 font-weight-normal" href="#">Avasta Dash</a></li>
                    <li class="mb-6"><a class="heading-default-color font-size-4 font-weight-normal" href="#">UI Design</a></li>
                  </ul>
                </div>
              </div>
              <div class="col-lg-3 col-md-6 col-sm-3 col-xs-6">
                <div class="footer-widget widget4">
                  <p class="widget-title font-size-4 text-gray mb-md-8 mb-7">Legal</p>
                  <ul class="widget-links pl-0 list-unstyled list-hover-primary">
                    <li class="mb-6"><a class="heading-default-color font-size-4 font-weight-normal" href="#">Privacy Policy</a></li>
                    <li class="mb-6"><a class="heading-default-color font-size-4 font-weight-normal" href="#">Terms &amp; Conditions</a></li>
                    <li class="mb-6"><a class="heading-default-color font-size-4 font-weight-normal" href="#">Return Policy</a></li>
                  </ul>
                </div>
              </div>
              <div class="col-lg-3 col-md-6 col-sm-3 col-xs-6">
                <!-- <div class="mt-8"> -->
                  <p class="widget-title font-size-4 text-gray mb-md-8 mb-7">Contact Information</p>
                   <h3 class="font-size-4"></h3>
                   <div class="media mb-2">
                     <div class="mr-6">
                       <i class="fas fa-map-marker-alt mt-2"></i>
                     </div>
                     <p class="font-size-4 mb-0 heading-default-color">If you have <br> any queries, <br>please contact us</p>
                   </div>
                   <div class="media mb-2">
                     <div class="mr-6">
                       <i class="fas fa-phone-alt mt-2"></i>
                     </div>
                     <p class="font-size-4 mb-0 heading-default-color">+91 8448359189</p>
                   </div>
                   <div class="media mb-2">
                     <div class="mr-6">
                       <i class="fas fa-envelope mt-2"></i>
                     </div>
                     <p class="font-size-4 mb-0 heading-default-color">itm.recruitmentservices@gmail.com</p>
                   </div>
                 <!-- </div> -->
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>