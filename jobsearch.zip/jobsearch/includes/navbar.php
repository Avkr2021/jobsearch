<style type="text/css">
   .active_nav {
     border-bottom: 2px solid #00b074;
   }
</style>
<header>
   <nav class="navbar">
      <div class="container">
         <div class="navbar-header">
            <button id="mobile_nav_toggler" class="navbar-toggler" data-toggle="open-navbar1">
            <span></span>
            <span></span>
            <span></span>
            </button>
            <a href="#">
               <img src="image/logoITM.svg" alt="" class="header-logo">
            </a>
         </div>
         <div class="navbar-menu" id="open-navbar1">
            <ul class="navbar-nav">
               <li class=""><a href="index.php">Home</a></li>
               <!-- <li class="navbar-dropdown">
                  <a href="#" class="dropdown-toggler" data-dropdown="my-dropdown-id">
                  Services <i class="bi bi-chevron-down"></i>
                  </a>
                  <ul class="dropdown" id="my-dropdown-id">
                     <li><a href="admin.php">Admin Panel</a></li>
                     <li><a href="#">Page 2</a></li>
                     <li class="separator"></li>
                     <li><a href="#">Page 3</a></li>
                     <li class="separator"></li>
                     <li><a href="#">Page 4</a></li>
                  </ul>
               </li> -->
               <li><a href="about-us.php">About us</a></li>
               <li><a href="contact-us.php">Contact us</a></li>
               <li><a href="blog.php">Blog</a></li>
               <li><a href="admin.php">Admin</a></li>
            </ul>
         </div>
      </div>
   </nav>
</header>