<style type="text/css">
   .active_nav_admin {
       border-color: #00b074 !important;
       background: #eee;
   }
</style>
<div id="cm_3_id" class="cm_3 main_dashboard_inner_one w30">
<div class="my-10 px-11">
  <a href="add_job.php" class="btn btn-primary btn-xl w-100 text-uppercase"><span class="mr-5 d-inline-block">+</span>Post a new job</a>
</div>
<div class="main_admin_work">
   <div class="options buttonContainer">
      <ul class="admin_ul">
         <li><a class="" href="admin.php">Dashboard</a></li>
         <li><a class="" href="posted-job.php">Recently Posted Jobs</a></li>
         <li><a class="" href="applicants.php">Applicants</a></li>
         <li><a class="" href="messages.php">Messages</a></li>
         <li><a class="" href="view-all-jobs.php">View all jobs</a></li>
         <li><a class="" href="visitor_Info.php">Visitor Information</a></li>
         <li><a class="" href="operation.php">Operation</a></li>
         <li><a class="" href="setting.php">Setting</a></li>
         <li><a class="" href="javascript:void(0);">Test 3</a></li>
         <li><a class="" href="javascript:void(0);">Test 4</a></li>
      </ul>
   </div>
</div>
</div>


