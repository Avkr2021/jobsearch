
<div class="inner_header">
            <div class="logo_company">
               <svg id="toggle_btn" focusable="false" viewBox="0 0 24 24">
                  <path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"></path>
               </svg>
               <div class="brand-logo">
                  <a href="javascript:void(0);">
                  <img src="image/logo-main-black.png" alt="" class="light-version-logo default-logo header-logo">
                  </a>
               </div>
            </div>
            <div class="profile_photo">
               <div class="d-flex justify-content-center align-items-center">
                  <div class="support_btn">
                     <a href="#">Support</a>
                  </div>
               <div id="show_profile" class="inner_img">
                  <div class="header-btn-devider ml-auto ml-lg-5 pl-2 d-none d-xs-flex align-items-center">
                     <div>
                        <div class="dropdown show-gr-dropdown">
                           <a class="proile media ml-7 flex-y-center" href="javascript:void(0);" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              <div class="circle-40">
                                 <img src="image/header-profile.png" alt="">
                              </div>
                              <i class="fas fa-chevron-down heading-default-color ml-6"></i>
                           </a>
                           <div class="dropdown-menu gr-menu-dropdown dropdown-right border-0 border-width-2 py-2 w-auto bg-default" aria-labelledby="dropdownMenuLink">
                              <a class="dropdown-item py-2 font-size-3 font-weight-semibold line-height-1p2 text-uppercase" href="dashboard-settings.html">Settings </a>
                              <a class="dropdown-item py-2 font-size-3 font-weight-semibold line-height-1p2 text-uppercase" href="candidate-profile-main.html">Edit Profile</a>
                              <a class="dropdown-item py-2 text-red font-size-3 font-weight-semibold line-height-1p2 text-uppercase" href="#">Log Out</a>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               </div>
            </div>
         </div>