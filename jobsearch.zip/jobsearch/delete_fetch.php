<?php
include 'includes/config.php';
$sql = "SELECT * FROM `option_table`";
$result = mysqli_query($conn,$sql);
$output = "";
if (mysqli_num_rows($result) > 0) {
	$counter=1;
	while ($row = mysqli_fetch_assoc($result)) {
		
		$output .= "<tr>
						<th>{$counter}</th>
						<th><input data-name='{$row['product_id']}' id='name' type='text' class='cmno' name='pname' value='{$row['product_name']}'></th>
						<th><input data-name='{$row['product_id']}'  id='name' type='text' class='cmno' name='pqty' value='{$row['qty']}'></th>
						<th><input data-name='{$row['product_id']}' id='name' type='text' class='cmno' name='punit' value='{$row['unit_price']}'></th>
						<th><input data-name='{$row['product_id']}' id='name' type='text' class='cmno' disabled name='ptotal' value='{$row['total_price']}'></th>
						<th><input data-name='{$row['product_id']}' id='name' type='text' class='cmno' name='paddition' value='{$row['additional_price']}'></th>
						<th><button data-deletebtn='{$row['product_id']}' id='delete_btn'>Delete</button></th>
					</tr>";
			$counter++;
	}
	
	echo $output;
}

?>