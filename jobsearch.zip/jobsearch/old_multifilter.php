<!-- <!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
    
    <title>Multifilter</title>
    <style>
        .table-wrapper{
            overflow: auto;
            box-sizing: border-box;
            width: 100%;
            max-width: 100%;
            height: 100vh;
            overflow: scroll;
            padding: 20px;
            background: #fff;
        }
        table{
            width: 640px;
        }
        table tr th, table tr td{
            width: 20%;
            padding: .5em
        }
        .filters{
            display: flex;
            width: 640px;
            margin-bottom: 15px;
        }
        .filters .filter-container{
            width: 20%;
            padding: 0 5px;
        }
        .filters .filter-container input{
            width: 100%;
        }
    </style>
</head>
<body>
    <header>
        <h1 class="dlw-title">Multifilter</h1>
        <p class="dlw-description">Multifilter is jQuery Table Filtering Plugin.</p>
    </header>
    <section>
        <h2 class="dlw-subtitle">[1] Basic Table Filter</h2>
        <input type="text" name="daterange" />
        <div class="table-wrapper">
            <div class='filters'>
                <div class='filter-container'>
                    <input id="myInput_one" autocomplete='off' class='filter' name='number' placeholder='Number' data-col='number' />
                </div>
                <div class='filter-container'>
                    <input id="myInput_two" autocomplete='off' class='filter' name='name' placeholder='Name' data-col='name' />
                </div>
                <div class='filter-container'>
                    <input autocomplete='off' class='filter' name='phone' placeholder='Phone' data-col='phone' />
                </div>
                <div class='filter-container'>
                    <input autocomplete='off' class='filter' name='date' placeholder='Date' data-col='date' />
                </div>
                <div class='filter-container'>
                    <input autocomplete='off' class='filter' name='company' placeholder='Company' data-col='company' />
                </div>
            </div>
            <table class="table-1">
                <thead class="">
                    <tr>
                        <th>Number</th>
                        <th>Name</th>
                        <th>Phone</th>
                        <th>Date</th>
                        <th>Company</th>
                    </tr>
                </thead>
                <tbody id="set_data" class="">
                    
                    
                </tbody>
            </table>
        </div>
    </section>





<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<script type="text/javascript" src="js/multifilter.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/jquery/latest/jquery.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script> -->
    <!-- <script>
        $(function () {
            $('.filter').multifilter();
        });
        
    </script>
    <script> -->

<!-- // based on date range picker ++++++++++++++++++++++

// $(function() {
//   $('input[name="daterange"]').daterangepicker({
//     opens: 'left'
//   }, function(start, end, label) {
//     var start = start.format('DD/MM/YYYY');
//     var end = end.format('DD/MM/YYYY');
//     $.ajax({
//         url: 'get_multifilter.php',
//         type: 'POST',
//         data: {start_key:start, end_key:end},
//         success: function (data) {
//            $('#set_data').html(data);
//         }
//     })
//   })
// });

// $(document).ready(function(){
//   $("#myInput_one").on("keyup", function() {
//     var value = $(this).val().toLowerCase();
//      var abc = $("#set_data tr").filter(function() {
//       $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
//     });
//   });
// });


// based on date range picker end ++++++++++++++++++++++ -->



<!-- //</script> -->
<!-- </body>
</html> -->

<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://unpkg.com/bootstrap-table@1.20.0/dist/bootstrap-table.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
    <title>Multifilter</title>
</head>
<body>
    <header>
        <h1 class="dlw-title">Multifilter</h1>
        <p class="dlw-description">Multifilter is jQuery Table Filtering Plugin.</p>
    </header>
    <section>
        <h2 class="dlw-subtitle">[1] Basic Table Filter</h2>
        
        <div class="table-wrapper">
            <!-- <div class='filters'>
                <div class='filter-container'>
                    <input autocomplete='off' class='filter' name='number' placeholder='Number' data-col='number' />
                </div>
                <div class='filter-container'>
                    <input autocomplete='off' class='filter' name='name' placeholder='Name' data-col='name' />
                </div>
                <div class='filter-container'>
                    <input autocomplete='off' class='filter' name='phone' placeholder='Phone' data-col='phone' />
                </div>
                <div class='filter-container'>
                    <input autocomplete='off' class='filter' name='date' placeholder='Date' data-col='date' />
                </div>
                <div class='filter-container'>
                    <input autocomplete='off' class='filter' name='company' placeholder='Company' data-col='company' />
                </div>
            </div> -->
            <!-- <table class="table-1">
                <thead>
                    <tr>
                        <th>Number</th>
                        <th>Name</th>
                        <th>Phone</th>
                        <th>Date</th>
                        <th>Company</th>
                    </tr>
                </thead>
                <tbody id="set_data"> -->
                    <!-- <tr>
                        <td>16910227-3118</td>
                        <td>Holmes</td>
                        <td>(420) 462-6063</td>
                        <td>2005/12/08</td>
                        <td>Scelerisque Corp.</td>
                    </tr>
                    <tr>
                        <td>16350601-7627</td>
                        <td>Randall</td>
                        <td>(845) 567-4878</td>
                        <td>2010/10/09</td>
                        <td>Pretium Et Rutrum Industries</td>
                    </tr>
                    <tr>
                        <td>16970730-2619</td>
                        <td>Vincent</td>
                        <td>(818) 509-2903</td>
                        <td>2014/06/17</td>
                        <td>Elit Dictum Inc.</td>
                    </tr>
                    <tr>
                        <td>16111213-5809</td>
                        <td>Brenden</td>
                        <td>(492) 783-8892</td>
                        <td>2001/08/26</td>
                        <td>Leo Elementum Company</td>
                    </tr>
                    <tr>
                        <td>16520608-1829</td>
                        <td>Cody</td>
                        <td>(182) 681-8933</td>
                        <td>2016/04/27</td>
                        <td>Eu Odio Ltd</td>
                    </tr>
                    <tr>
                        <td>16430718-1323</td>
                        <td>Emery</td>
                        <td>(741) 687-8269</td>
                        <td>2007/04/29</td>
                        <td>Nulla Limited</td>
                    </tr>
                    <tr>
                        <td>16850111-9047</td>
                        <td>Allistair</td>
                        <td>(753) 841-4140</td>
                        <td>2004/12/31</td>
                        <td>Euismod Est Arcu PC</td>
                    </tr>
                    <tr>
                        <td>16601201-7973</td>
                        <td>Michael</td>
                        <td>(138) 652-2400</td>
                        <td>2001/09/18</td>
                        <td>In Consectetuer Ipsum PC</td>
                    </tr>
                    <tr>
                        <td>16321225-0488</td>
                        <td>Carter</td>
                        <td>(455) 949-1753</td>
                        <td>2003/09/21</td>
                        <td>Dolor Quisque Tincidunt Company</td>
                    </tr>
                    <tr>
                        <td>16230626-1823</td>
                        <td>Salvador</td>
                        <td>(674) 692-0833</td>
                        <td>2001/07/16</td>
                        <td>Suspendisse Institute</td>
                    </tr>
                    <tr>
                        <td>16661025-7005</td>
                        <td>Ronan</td>
                        <td>(281) 156-8865</td>
                        <td>2010/10/31</td>
                        <td>Non PC</td>
                    </tr>
                    <tr>
                        <td>16570617-9743</td>
                        <td>Logan</td>
                        <td>(933) 597-1161</td>
                        <td>2013/05/26</td>
                        <td>Ipsum Dolor Sit Inc.</td>
                    </tr>
                    <tr>
                        <td>16290103-1043</td>
                        <td>Raymond</td>
                        <td>(292) 937-5017</td>
                        <td>2011/07/18</td>
                        <td>Egestas Company</td>
                    </tr> -->
                <!-- </tbody>
            </table> -->

            <table
              id="table"
              data-toggle="table"
              data-height="460"
              data-url="json/data8.json"
              data-pagination="true"
              data-side-pagination="server"
              data-total-field="count"
              data-data-field="items">
              <thead>
                <tr>
                  <th data-field="id">ID</th>
                  <th data-field="name">Item Name</th>
                  <th data-field="price">Item Price</th>
                  <th data-field="Non">Non PC</th>
                </tr>
              </thead>
              <tr>
                        <td>16910227-3118</td>
                        <td>Holmes</td>
                        <td>(420) 462-6063</td>
                        <td>2005/12/08</td>
                        <td>Scelerisque Corp.</td>
                    </tr>
                    <tr>
                        <td>16350601-7627</td>
                        <td>Randall</td>
                        <td>(845) 567-4878</td>
                        <td>2010/10/09</td>
                        <td>Pretium Et Rutrum Industries</td>
                    </tr>
                    <tr>
                        <td>16970730-2619</td>
                        <td>Vincent</td>
                        <td>(818) 509-2903</td>
                        <td>2014/06/17</td>
                        <td>Elit Dictum Inc.</td>
                    </tr>
                    <tr>
                        <td>16111213-5809</td>
                        <td>Brenden</td>
                        <td>(492) 783-8892</td>
                        <td>2001/08/26</td>
                        <td>Leo Elementum Company</td>
                    </tr>
                    <tr>
                        <td>16520608-1829</td>
                        <td>Cody</td>
                        <td>(182) 681-8933</td>
                        <td>2016/04/27</td>
                        <td>Eu Odio Ltd</td>
                    </tr>
                    <tr>
                        <td>16430718-1323</td>
                        <td>Emery</td>
                        <td>(741) 687-8269</td>
                        <td>2007/04/29</td>
                        <td>Nulla Limited</td>
                    </tr>
                    <tr>
                        <td>16850111-9047</td>
                        <td>Allistair</td>
                        <td>(753) 841-4140</td>
                        <td>2004/12/31</td>
                        <td>Euismod Est Arcu PC</td>
                    </tr>
                    <tr>
                        <td>16601201-7973</td>
                        <td>Michael</td>
                        <td>(138) 652-2400</td>
                        <td>2001/09/18</td>
                        <td>In Consectetuer Ipsum PC</td>
                    </tr>
                    <tr>
                        <td>16321225-0488</td>
                        <td>Carter</td>
                        <td>(455) 949-1753</td>
                        <td>2003/09/21</td>
                        <td>Dolor Quisque Tincidunt Company</td>
                    </tr>
                    <tr>
                        <td>16230626-1823</td>
                        <td>Salvador</td>
                        <td>(674) 692-0833</td>
                        <td>2001/07/16</td>
                        <td>Suspendisse Institute</td>
                    </tr>
                    <tr>
                        <td>16661025-7005</td>
                        <td>Ronan</td>
                        <td>(281) 156-8865</td>
                        <td>2010/10/31</td>
                        <td>Non PC</td>
                    </tr>
                    <tr>
                        <td>16570617-9743</td>
                        <td>Logan</td>
                        <td>(933) 597-1161</td>
                        <td>2013/05/26</td>
                        <td>Ipsum Dolor Sit Inc.</td>
                    </tr>
                    <tr>
                        <td>16290103-1043</td>
                        <td>Raymond</td>
                        <td>(292) 937-5017</td>
                        <td>2011/07/18</td>
                        <td>Egestas Company</td>
                    </tr>
            </table>
        </div>
    </section>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous"></script>
    <script src="https://unpkg.com/bootstrap-table@1.20.0/dist/bootstrap-table.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <script type="text/javascript" src="js/multifilter.js"></script>
    <script>
        $(function () {
            $('.filter').multifilter();
        });
    </script>
    <script type="text/javascript">
        function gettt() {
           $.ajax({
                url: 'get_multifilter.php',
                type: 'POST',
                success: function (data) {
                   $('#set_data').html(data);
                }
            })
        }
        gettt();
        
    </script>
</body>
</html>