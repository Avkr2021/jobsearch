<?php  
include 'includes/config.php';
$unq_id = $_POST['get_delete_key'];
$sql = "DELETE FROM `option_table` WHERE product_id = '$unq_id'";
$result = mysqli_query($conn , $sql) or die();
if ($result) {
	echo "0";
} else {
	echo "1";
}

?>