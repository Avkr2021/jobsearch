<!doctype html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <meta name="robots" content="noindex" />
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
      <link rel="stylesheet" href="assets/css/style.css">
      <!-- <link rel="shortcut icon" href="image/favicon.png" type="image/x-icon"> -->
      <!-- Bootstrap , fonts & icons  -->
      <link rel="stylesheet" href="css/bootstrap.css">
      <link rel="stylesheet" href="fonts/icon-font/css/style.css">
      <link rel="stylesheet" href="fonts/typography-font/typo.css">
      <link rel="stylesheet" href="fonts/fontawesome-5/css/all.css">
      <!-- Plugin'stylesheets  -->
      <link rel="stylesheet" href="plugins/fancybox/jquery.fancybox.min.css">
      <!-- <link rel="stylesheet" href="plugins/nice-select/nice-select.min.css"> -->
      <link rel="stylesheet" href="plugins/slick/slick.min.css">
      <link rel="stylesheet" href="plugins/ui-range-slider/jquery-ui.css">
      <!-- Vendor stylesheets  -->
      <link rel="stylesheet" href="css/main.css">
      <!-- Custom stylesheet -->
      <title>Developer Testing</title>
      <style>
         .form-control {
             border: 1px solid #cbcbcb !important;
         }
         .choose_city_dropdown .nice-select {
            width: 100%;
            border: solid 1px #cbcbcb;
         }
         .restarat input {
            width: 100%;
            border: none;
         }
         .restarat input:focus {
            outline: none;
         }


      </style>
   </head>
   <body>
      <div class="outer_box">
         <!-- header admin -->
         <?php include 'includes/new_admin_header.php' ?>
         <!-- header admin -->
         <div class="main_dashboard_area_outer">
            <!-- nav admin -->
            <?php include 'includes/new_admin_nav.php' ?>
            <!-- nav admin -->
            <div id="cm_4_id" class="cm_3 main_dashboard_inner_two w70">
               <!-- +++++++++++++++++++++ tab one ++++++++++++++++++++++ -->
               <div class="cm_admin tabPanel">
                  <section class="outer_main_div">
                     <div class="container-fluid">
                        <div class="row">
                           <div class="col-md-12">
                              <div class="contact-form bg-white apply_form_border rounded-4 pl-sm-10 pl-4 pr-sm-11 pr-4 pt-8 pb-13">
                                 <div class="row pb-10">
                                    <div class="col-12 d-flex align-items-center justify-content-between">
                                       <h4 class="form_head_post mb-0">Setting</h4>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-12">
                                       <table width="80%" border="1px" class="restarat">
                                          <thead>
                                             <tr>
                                                <th>S. no.</th>
                                                <th>First Name</th>
                                                <th>Last NAme</th>
                                             </tr>
                                          </thead>
                                          <tbody>
                                             <tr>
                                                <td>1</td>
                                                <td><input id="ouuoo" type="text" name=""></td>
                                                <td><input id="buubb" type="text" name=""></td>
                                             </tr>
                                          </tbody>
                                       </table>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div style="height: 20px;"></div>
                  </section>
               </div>
               <!-- +++++++++++++++++++++ tab two ++++++++++++++++++++++ -->
            </div>
         </div>
      </div>
      <!-- +++++++++++++++ Put your all code before this line ++++++++++++ -->
      <!-- +++++++++++++++++++ code end +++++++++++++++++ -->
      <script src="assets/jquery/jquery.js"></script>
      <script src="plugins/fancybox/jquery.fancybox.min.js"></script>
      <script src="plugins/slick/slick.min.js"></script>
      <script src="plugins/counter-up/jquery.counterup.min.js"></script>
      <script src="plugins/counter-up/jquery.waypoints.min.js"></script>
      <script src="plugins/ui-range-slider/jquery-ui.js"></script>
      <script src="js/custom.js"></script>
      <script>
         $(document).ready(function () {
           $('#toggle_btn').click(function () {
             $('#cm_3_id').toggleClass('invisible');
             $('#cm_4_id').toggleClass('invisibleTwo');
           })
         });
         $('#show_fild_city').click(function () {
            $('#show_fild_city_inner').toggle(100);
         })
      </script>
      <script type="text/javascript">
            function get_val() {
               $.ajax({
                  url: 'ajaxfils/keyup_fetch.php',
                  type: 'POST',
                  success: function (data) {
                     console.log(data);
                  }
               })
            }

            $('input').blur(function () {
               var get_one = $('#ouuoo').val();
               var get_two = $('#buubb').val();
               $.ajax({
                  url: 'ajaxfils/keyup.php',
                  type: 'POST',
                  data: {get_one_key:get_one, get_two_key:get_two},
                  success: function (data) {
                     console.log(data);
                  }
               })
            })
            $('input').blur(function () {
               var get_one = $('#ouuoo').val();
               var get_two = $('#buubb').val();
               $.ajax({
                  url: 'ajaxfils/keyup.php',
                  type: 'POST',
                  data: {get_one_key:get_one, get_two_key:get_two},
                  success: function (data) {
                     console.log(data);
                  }
               })
            })

         

    
      </script>
      <script type="text/javascript">
         $(function($) {
            let url = window.location.href;
            $('ul.admin_ul li a').each(function() {
              if (this.href === url) {
                $(this).closest('a').addClass('active_nav_admin');
              }
            });
          });
      </script>
   </body>
</html>