<?php 	 
include 'includes/config.php';

$sql = "SELECT SUM(qty) AS sum_price FROM option_table";
$result = mysqli_query($conn , $sql);
$row = mysqli_fetch_array($result);
echo $row['sum_price'];


//`product_id`, `product_name`, `qty`, `unit_price`, `total_price`, `additional_price` option_table
?>