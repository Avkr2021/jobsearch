<!doctype html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <meta name="robots" content="noindex" />
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
      <link rel="stylesheet" href="assets/css/style.css">
      <!-- <link rel="shortcut icon" href="image/favicon.png" type="image/x-icon"> -->
      <!-- Bootstrap , fonts & icons  -->
      <link rel="stylesheet" href="css/bootstrap.css">
      <link rel="stylesheet" href="fonts/icon-font/css/style.css">
      <link rel="stylesheet" href="fonts/typography-font/typo.css">
      <link rel="stylesheet" href="fonts/fontawesome-5/css/all.css">
      <!-- Plugin'stylesheets  -->
      <link rel="stylesheet" href="plugins/fancybox/jquery.fancybox.min.css">
      <!-- <link rel="stylesheet" href="plugins/nice-select/nice-select.min.css"> -->
      <link rel="stylesheet" href="plugins/slick/slick.min.css">
      <link rel="stylesheet" href="plugins/ui-range-slider/jquery-ui.css">
      <!-- Vendor stylesheets  -->
      <link rel="stylesheet" href="css/main.css">
      <!-- Custom stylesheet -->
      <title>Developer Testing</title>
      <style>
         .form-control {
             border: 1px solid #cbcbcb !important;
         }
         .choose_city_dropdown .nice-select {
            width: 100%;
            border: solid 1px #cbcbcb;
         }
      </style>
   </head>
   <body>
      <div class="outer_box">
         <!-- header admin -->
         <?php include 'includes/new_admin_header.php' ?>
         <!-- header admin -->
         <div class="main_dashboard_area_outer">
            <!-- nav admin -->
            <?php include 'includes/new_admin_nav.php' ?>
            <!-- nav admin -->
            <div id="cm_4_id" class="cm_3 main_dashboard_inner_two w70">
               <!-- +++++++++++++++++++++ tab one ++++++++++++++++++++++ -->
               <div class="cm_admin tabPanel">
                  <section class="outer_main_div">
                     <div class="container-fluid">
                        <div class="row">
                           <div class="col-md-12">
                              <div class="contact-form bg-white apply_form_border rounded-4 pl-sm-10 pl-4 pr-sm-11 pr-4 pt-8 pb-13">
                                 <div class="row pb-10">
                                    <div class="col-12 d-flex align-items-center justify-content-between">
                                       <h4 class="form_head_post mb-0">Post a new job</h4>
                                       <div class="add_new_city">
                                          <a href="#" id="show_fild_city" class="inner_city_add">&#43; Add City</a>
                                          <div id="show_fild_city_inner" class="inner_add_form_city">
                                             <input id="city_name" class="form-control" type="" name="" placeholder="e.g. Delhi"><button id="save_city">Save</button>
                                          </div>
                                       </div> 
                                    </div>
                                 </div>
                                 <form id="add_job_form_main" class="add_UiPDds">
                                    <fieldset class="apply_fildset">
                                       <div class="row mb-xl-1 mb-9">
                                          <div class="col-lg-4">
                                             <div class="form-group">
                                                <label for="namedash" class="d-block text-black-2 font-size-4 font-weight-semibold mb-4">Job Title</label>
                                                <input type="text" class="form-control h-px-48" id="job_title" placeholder="e.g Telecaller">
                                             </div>
                                            <div class="form-group choose_city_dropdown">
                                                <label for="namedash" class="d-block text-black-2 font-size-4 font-weight-semibold mb-4">Select City</label>
                                                <select id="add_city_dropdown_one" class="h-px-48">
                                                </select>
                                             </div>
                                          </div>
                                          <div class="col-lg-8">
                                             <div class="form-group">
                                                <label for="namedash" class="d-block text-black-2 font-size-4 font-weight-semibold mb-4">Description</label>
                                                <textarea rows="5"  type="text" class="form-control" id="job_disc" placeholder="e.g. Urgently Hiring for a Full time Web Designer"></textarea>
                                             </div>
                                          </div>
                                          <div class="col-lg-4">
                                             <div class="form-group">
                                                <label for="" class="d-block text-black-2 font-size-4 font-weight-semibold mb-4">Schedule:</label>
                                                <input type="text" class="form-control h-px-48" id="job_schedule" placeholder="e.g Day Shift">
                                             </div>
                                          </div>
                                          <div class="col-lg-4">
                                             <div class="form-group">
                                                <label for="" class="d-block text-black-2 font-size-4 font-weight-semibold mb-4">Education:</label>
                                                <input type="text" class="form-control h-px-48" id="job_education" placeholder="e.g. 12th Pass">
                                             </div>
                                          </div>
                                          <div class="col-lg-4">
                                             <div class="form-group">
                                                <label for="" class="d-block text-black-2 font-size-4 font-weight-semibold mb-4">Speak with the employer</label>
                                                <input type="text" class="form-control h-px-48" id="job_mobile" placeholder="e.g. 9123758694">
                                             </div>
                                          </div>
                                          <div class="col-lg-4">
                                             <div class="form-group">
                                                <label for="" class="d-block text-black-2 font-size-4 font-weight-semibold mb-4">Pay Scale</label>
                                                <input type="text" class="form-control h-px-48" id="job_salary" placeholder="15000-20000">
                                             </div>
                                          </div>
                                          <div class="col-lg-4">
                                             <div class="form-group">
                                                <label for="" class="d-block text-black-2 font-size-4 font-weight-semibold mb-4">Key Points:</label>
                                                <div class="main_btn_div">
                                                   <button id="add_field" class="add_o">Add</button>
                                                   <button id="remove_field" class="add_i">Remove</button>
                                                </div>
                                                <div id="new_chq">
                                                   <input type="hidden" value="1" id="total_chq">
                                                  <input type="text" name='multifield' class="form-control mb-2 h-px-48" id="job_resp" placeholder="e.g ">
                                                </div>
                                             </div>
                                          </div>
                                          <div class="col-lg-4">
                                             <div class="form-group">
                                                <label for="" class="d-block text-black-2 font-size-4 font-weight-semibold mb-4">Experience:</label>
                                                <div class="main_btn_div">
                                                   <button id="add_field_exp" class="add_o">Add</button>
                                                   <button id="remove_field_exp" class="add_i">Remove</button>
                                                </div>
                                                <div id="new_chq_exp">
                                                   <input type="hidden" value="1" id="total_chq_exp">
                                                   <input type="text" name='multifield_exp' class="form-control mb-2 h-px-48" id="job_expr" placeholder="e.g. Freshers, 2 Yers">
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="row">
                                          <div class="col-md-12">
                                             <div>
                                                <input id="add_job_sbmt" type="button" value="Submit" class="btn btn-green btn-h-60 text-white min-width-px-210 rounded-5 text-uppercase">
                                             </div>
                                          </div>
                                       </div>
                                    </fieldset>
                                 </form>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div style="height: 20px;"></div>
                  </section>
               </div>
               <!-- +++++++++++++++++++++ tab two ++++++++++++++++++++++ -->
            </div>
         </div>
      </div>
      <!-- +++++++++++++++ Put your all code before this line ++++++++++++ -->
      <!-- +++++++++++++++++++ code end +++++++++++++++++ -->
      <script src="assets/jquery/jquery.js"></script>
      <script src="plugins/fancybox/jquery.fancybox.min.js"></script>
      <!-- <script src="plugins/nice-select/jquery.nice-select.min.js"></script> -->
      <!-- <script src="plugins/aos/aos.min.js"></script> -->
      <script src="plugins/slick/slick.min.js"></script>
      <script src="plugins/counter-up/jquery.counterup.min.js"></script>
      <script src="plugins/counter-up/jquery.waypoints.min.js"></script>
      <script src="plugins/ui-range-slider/jquery-ui.js"></script>
      <script src="js/custom.js"></script>
      <script>
         $(document).ready(function () {
           $('#toggle_btn').click(function () {
             $('#cm_3_id').toggleClass('invisible');
             $('#cm_4_id').toggleClass('invisibleTwo');
           })
         });
         $('#show_fild_city').click(function () {
            $('#show_fild_city_inner').toggle(100);
         })
         // hide on body click ----------------
         $('body').click(function (e) {
                if($(e.target).closest("#show_fild_city").length ===  0 && $(e.target).closest("#show_fild_city_inner").length ===  0) {  
                $('#show_fild_city_inner').hide();
               }
           });
      </script>
        <script type="text/javascript">
            
            $('#add_field').click(function (e) {
              e.preventDefault();
              var new_chq_no = parseInt($('#total_chq').val())+1;
               var new_input="<input class='form-control mb-2 h-px-48' type='text' name='multifield' id='new_"+new_chq_no+"'>";
               $('#new_chq').append(new_input);
               $('#total_chq').val(new_chq_no);
             })

          $('#remove_field').click(function (e) {
            e.preventDefault();
            var last_chq_no = $('#total_chq').val();
            if(last_chq_no>1){
              $('#new_'+last_chq_no).remove();
              $('#total_chq').val(last_chq_no-1);
            }
          })

          // experience add remove button ----------------

          $('#add_field_exp').click(function (e) {
              e.preventDefault();
              var new_chq_no = parseInt($('#total_chq_exp').val())+1;
               var new_input="<input class='form-control mb-2 h-px-48' type='text' name='multifield_exp' id='newExp_"+new_chq_no+"'>";
               $('#new_chq_exp').append(new_input);
               $('#total_chq_exp').val(new_chq_no);
             })

          $('#remove_field_exp').click(function (e) {
            e.preventDefault();
            var last_chq_no = $('#total_chq_exp').val();
            if(last_chq_no>1){
              $('#newExp_'+last_chq_no).remove();
              $('#total_chq_exp').val(last_chq_no-1);
            }
          })

          // experience add remove button end ----------------
          // second ------------
          $('#add_job_sbmt').click(function () {
            types = []; 
            ftxt = "";
            $("input[name='multifield']").each(function() {
              var txt = $(this).val() || '';
              txt = txt.trim();
              ftxt    = ftxt+txt +'#$';

            });

            ftxtn = "";
            $("input[name='multifield_exp']").each(function() {
              var txt = $(this).val() || '';
              txt = txt.trim();
              ftxtn    = ftxtn+txt +'#$';

            });

               var job_desc_js = $('#job_disc').val();
               var job_schedule_js = $('#job_schedule').val();
               var job_education_js = $('#job_education').val();
               var add_city_dropdown_js = $('#add_city_dropdown_one').val();
               var job_expr_js = $('#job_expr').val();
               var job_mobile_js = $('#job_mobile').val();
               var job_title_js = $('#job_title').val();
               var job_salary_js = $('#job_salary').val();
               var ftxt_js = ftxt;
               var job_expr_js = ftxtn;

               // alert(job_desc_js +'|'+job_schedule_js+'|'+job_education_js+'|'+add_city_dropdown_js+'|'+job_expr_js+'|'+job_mobile_js+'|'+job_title_js+'|'+job_salary_js+'|'+ftxt_js);

               if (job_title_js == '') {
                  if (confirm('Job Title field is empty do you want to proceed ahead ?')) {
                  } else {
                     die();
                  }
               }
               if (job_desc_js == '') {
                  if (confirm('Discription field is empty do you want to proceed ahead ?')) {
                  } else {
                     die();
                  }
               }
               if ( add_city_dropdown_js == '') {
                  if (confirm('Location field is empty do you want to proceed ahead ?')) {
                  } else {
                     die();
                  }
               }
               if (job_schedule_js == '') {
                  if (confirm('Schedule field is empty do you want to proceed ahead ?')) {
                  } else {
                     die();
                  }
               }
               if (job_education_js == '') {
                  if (confirm('Education field is empty do you want to proceed ahead ?')) {
                  } else {
                     die();
                  }
               }
               if (job_expr_js == '') {
                  if (confirm('Experience field is empty do you want to proceed ahead ?')) {
                  } else {
                     die();
                  }
               }
               if (ftxt_js == '') {
                  if (confirm('Key Points field is empty do you want to proceed ahead ?')) {
                  } else {
                     die();
                  }
               }
               if (job_salary_js == '') {
                  if (confirm('Salary field is empty do you want to proceed ahead ?')) {
                  } else {
                     die();
                  }
               }
               if (job_mobile_js == '') {
                  if (confirm('Mobile field is empty do you want to proceed ahead ?')) {
                  } else {
                     die();
                  }
               }
               $.ajax({
                   url: 'ajaxfils/addjob_transfer_data.php',
                   type: 'POST',
                   data: {
                     bullet_js_key: ftxt_js,
                     job_desc_js_key:job_desc_js,
                     job_location_js_key:add_city_dropdown_js,
                     job_schedule_js_key:job_schedule_js,
                     job_education_js_key:job_education_js,
                     job_expr_js_key:job_expr_js,
                     job_mobile_js_key:job_mobile_js,
                     job_title_js_key:job_title_js,
                     job_salary_js_key:job_salary_js
                  },
                   success: function (data) {
                    if (data == 0) {
                     alert('Job Added Successfully');
                     $('#add_job_form_main').trigger('reset');
                    }
                   }
               })
                        
          });

          // add city name --------------

          $('#save_city').click(function () {
             var city_name = $('#city_name').val();
             if (city_name !== '') {
               $.ajax({
                  url: 'ajaxfils/add_city.php',
                  type: 'POST',
                  data: {city_name_key: city_name},
                  success: function (data) {
                     if (data == 0) {
                        alert('City Added Successfully');
                        $('#show_fild_city_inner').hide(100);
                     } else {
                        alert('Failed to save data');
                     }
                  }
               })
             } else {
               alert('Field is empty')
             }
          })

          // get city name --------------

          function ge_city_name() {
            $.ajax({
               url: 'ajaxfils/get_city_name_job.php',
               type: 'POST',
               success: function (data) {
                  $('#add_city_dropdown_one').html(data);
                  // alert(data);
               }
            })
          }
          ge_city_name();

         
  </script>
  <script type="text/javascript">
      $(function($) {
         let url = window.location.href;
         $('ul.admin_ul li a').each(function() {
           if (this.href === url) {
             $(this).closest('a').addClass('active_nav_admin');
           }
         });
       });
   </script>
   </body>
</html>