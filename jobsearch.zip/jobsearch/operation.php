<!doctype html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <meta name="robots" content="noindex" />
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
      <link rel="stylesheet" href="assets/css/style.css">
      <!-- <link rel="shortcut icon" href="image/favicon.png" type="image/x-icon"> -->
      <!-- Bootstrap , fonts & icons  -->
      <link rel="stylesheet" href="css/bootstrap.css">
      <link rel="stylesheet" href="fonts/icon-font/css/style.css">
      <link rel="stylesheet" href="fonts/typography-font/typo.css">
      <link rel="stylesheet" href="fonts/fontawesome-5/css/all.css">
      <!-- Plugin'stylesheets  -->
      <link rel="stylesheet" href="plugins/fancybox/jquery.fancybox.min.css">
      <link rel="stylesheet" href="plugins/nice-select/nice-select.min.css">
      <link rel="stylesheet" href="plugins/slick/slick.min.css">
      <link rel="stylesheet" href="plugins/ui-range-slider/jquery-ui.css">
      <!-- Vendor stylesheets  -->
      <link rel="stylesheet" href="css/main.css">
      <!-- Custom stylesheet -->
      <title>Developer Testing</title>
      <style>
            
      </style>
   </head>
   <body>
      
      <div class="outer_box">
         <!-- header admin -->
         <?php // include 'includes/new_admin_header.php' ?>
         <!-- header admin -->
         <div class="main_dashboard_area_outer">
            <!-- nav admin -->
            <?php // include 'includes/new_admin_nav.php' ?>
            <!-- nav admin -->
            <div id="cm_4_id" class="cm_3 main_dashboard_inner_two w70">
               <!-- +++++++++++++++++++++ tab one ++++++++++++++++++++++ -->
               <div class="cm_admin tabPanel">
                  <div class="change_in_website add_product">
                     <h4>Operation</h4>
                     <!-- <div class="search_bar_applicants">
                        <input id="search_applicants_post" type="text" placeholder="Search">
                     </div>
                     <div class="filter_product">
                        <select id="add_city_dropdown_post"></select>
                     </div> -->
                     <!-- <div>
                        <div>     
                           <button id="add_prdt_id" class="add_btn_new">Add Product</button>
                        </div>
                     </div> -->
                  </div>
                  <div class="details_author details_author_new main_tab_webv">
                     <nav>
                       <div class="nav nav-tabs" id="nav-tab" role="tablist">
                         <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Posted Jobs</a>
                         <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Job Location</a>
                         <a class="nav-item nav-link" id="nav-contact-tab" data-toggle="tab" href="#nav-contact" role="tab" aria-controls="nav-contact" aria-selected="false">Applicants</a>
                       </div>
                     </nav>
                     <div class="tab-content" id="nav-tabContent">
                       <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                          <table border="1" cellpadding="5px" cellspacing="0px" width="100%">
                              <thead>
                                 <tr>
                                    <th>Job Title</th>
                                    <th>Location</th>
                                    <th>Education</th>
                                    <th>Description</th>
                                    <th>Mobile</th>
                                    <th>Salary</th>
                                    <th>Save Data</th>
                                    <th class="text-center">Action</th>
                                 </tr>
                              </thead>
                              <tbody id="show_posted_job">
                                 
                              </tbody>
                           </table>
                       </div>
                       <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">B</div>
                       <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">C</div>
                     </div>
                  </div>
                  <div style="height: 20px;"></div>
                  <!-- ooooo --><!-- ooooo -->
               </div>
               <!-- +++++++++++++++++++++ tab one ++++++++++++++++++++++ -->
            </div>
         </div>
         <!-- -------------end---------------- -->
      </div>
      <!-- +++++++++++++++++++ code end +++++++++++++++++ -->
      <script src="assets/jquery/jquery.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"></script>
      <script src="js/custom.js"></script>
      <!-- <script src="plugins/fancybox/jquery.fancybox.min.js"></script> -->
      <!-- <script src="plugins/nice-select/jquery.nice-select.min.js"></script> -->
      <!-- <script src="plugins/aos/aos.min.js"></script> -->
      <!-- <script src="plugins/slick/slick.min.js"></script> -->
      <!-- <script src="plugins/counter-up/jquery.counterup.min.js"></script>
      <script src="plugins/counter-up/jquery.waypoints.min.js"></script> -->
      <!-- <script src="plugins/ui-range-slider/jquery-ui.js"></script> -->
      
      <script>
           $('#toggle_btn').click(function () {
             $('#cm_3_id').toggleClass('invisible');
             $('#cm_4_id').toggleClass('invisibleTwo');
           });
           $(function($) {
            let url = window.location.href;
            $('ul.admin_ul li a').each(function() {
              if (this.href === url) {
                $(this).closest('a').addClass('active_nav_admin');
              }
            });
          });
      </script>
      <script type="text/javascript">

         function loadPostedJob() {
              $.ajax({
               url: 'ajaxfils/loadPostedJob-operation.php',
               type: 'POST',
               success: function (data) {
                  $('#show_posted_job').html(data);
               }
              });
           }
           loadPostedJob();

         $(document).on('click','#edit_post',function () {
             $(this).closest('tbody tr').find('.tagid').removeAttr("disabled");
         })

         $(document).on('click','#save_data',function () {
             $(this).closest('tbody tr').find('.tagid').removeAttr("disabled");
             var edit_title = $(this).closest('tbody tr').find('#edit_title').val();
             var edit_location =  $(this).closest('tbody tr').find('#edit_location').val();
             var edit_education = $(this).closest('tbody tr').find('#edit_education').val();
             var edit_description = $(this).closest('tbody tr').find('#edit_description').val();
             var edit_mobile = $(this).closest('tbody tr').find('#edit_mobile').val();
             var edit_salary = $(this).closest('tbody tr').find('#edit_salary').val();
             // alert(edit_title + edit_location + edit_education + edit_description + edit_mobile + edit_salary);
             $.ajax({
               url: 'ajaxfils/update_posted_job.php',
               type: 'POST',
               data: {edit_title_key:edit_title, edit_location_key:edit_location, edit_education_key:edit_education,edit_description_key:edit_description, edit_mobile_key:edit_mobile, edit_salary_key:edit_salary},
               success: function (data) {
                  alert(data);
               }
             });
         })






    

      </script>
   </body>
</html>