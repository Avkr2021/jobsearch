<!doctype html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <meta name="robots" content="noindex" />
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
      <link rel="stylesheet" href="assets/css/style.css">
      <!-- <link rel="shortcut icon" href="image/favicon.png" type="image/x-icon"> -->
      <!-- Bootstrap , fonts & icons  -->
      <link rel="stylesheet" href="css/bootstrap.css">
      <link rel="stylesheet" href="fonts/icon-font/css/style.css">
      <link rel="stylesheet" href="fonts/typography-font/typo.css">
      <link rel="stylesheet" href="fonts/fontawesome-5/css/all.css">
      <!-- Plugin'stylesheets  -->
      <link rel="stylesheet" href="plugins/fancybox/jquery.fancybox.min.css">
      <link rel="stylesheet" href="plugins/nice-select/nice-select.min.css">
      <link rel="stylesheet" href="plugins/slick/slick.min.css">
      <link rel="stylesheet" href="plugins/ui-range-slider/jquery-ui.css">
      <!-- Vendor stylesheets  -->
      <link rel="stylesheet" href="css/main.css">
      <!-- Custom stylesheet -->
      <title>Developer Testing</title>
      
   </head>
   <body>
      <div class="outer_box">
         <!-- header admin -->
         <?php include 'includes/new_admin_header.php' ?>
         <!-- header admin -->
         <div class="main_dashboard_area_outer">
            <!-- nav admin -->
            <?php include 'includes/new_admin_nav.php' ?>
            <!-- nav admin -->
            <div id="cm_4_id" class="cm_3 main_dashboard_inner_two w70">
            <!-- +++++++++++++++++++++ tab one ++++++++++++++++++++++ -->
               <div class="cm_admin tabPanel">
                  <section class="outer_main_div">
                     <div class="container">
                       <div class="row mb-7">
                         <div class="col-xxl-3 col-xl-4 col-lg-6 col-sm-6">
                           <a href="#" class="media bg-white rounded-4 pl-8 pt-9 pb-9 pr-7 hover-shadow-1 mb-9 shadow-8">
                             <div class="text-blue bg-blue-opacity-1 circle-56 font-size-6 mr-7">
                               <i class="fas fa-briefcase"></i>
                             </div>
                             <div class="">
                               <h5 class="font-size-8 font-weight-semibold text-black-2 line-height-reset font-weight-bold mb-1"><span class="counter" id="set_job_count">00</span></h5>
                               <p class="font-size-4 font-weight-normal text-gray mb-0">Posted Jobs</p>
                             </div>
                           </a>
                         </div>
                         <div class="col-xxl-3 col-xl-4 col-lg-6 col-sm-6">
                           <a href="#" class="media bg-white rounded-4 pl-8 pt-9 pb-9 pr-7 hover-shadow-1 mb-9 shadow-8">
                             <div class="text-pink bg-pink-opacity-1 circle-56 font-size-6 mr-7">
                               <i class="fas fa-user"></i>
                             </div>
                             <div class="">
                               <h5 class="font-size-8 font-weight-semibold text-black-2 line-height-reset font-weight-bold mb-1"><span class="counter" id="set_applicants_count">00</span></h5>
                               <p class="font-size-4 font-weight-normal text-gray mb-0">Total Applicants</p>
                             </div>
                           </a>
                         </div>
                         <div class="col-xxl-3 col-xl-4 col-lg-6 col-sm-6">
                           <a href="#" class="media bg-white rounded-4 pl-8 pt-9 pb-9 pr-7 hover-shadow-1 mb-9 shadow-8">
                             <div class="text-orange bg-orange-opacity-1 circle-56 font-size-6 mr-7">
                               <i class="fas fa-eye"></i>
                             </div>
                             <div class="">
                               <h5 class="font-size-8 font-weight-semibold text-black-2 line-height-reset font-weight-bold mb-1"><span class="counter">16.5</span>K</h5>
                               <p class="font-size-4 font-weight-normal text-gray mb-0">Jobs View</p>
                             </div>
                           </a>
                         </div>
                         <div class="col-xxl-3 col-xl-4 col-lg-6 col-sm-6">
                           <a href="#" class="media bg-white rounded-4 pl-8 pt-9 pb-9 pr-7 hover-shadow-1 mb-9 shadow-8">
                             <div class="text-egg-blue bg-egg-blue-opacity-1 circle-56 font-size-6 mr-7">
                               <i class="fas fa-mouse-pointer"></i>
                             </div>
                             <div class="">
                               <h5 class="font-size-8 font-weight-semibold text-black-2 line-height-reset font-weight-bold mb-1"><span class="counter">18.6</span>%</h5>
                               <p class="font-size-4 font-weight-normal text-gray mb-0">Applied Rate</p>
                             </div>
                           </a>
                         </div>
                       </div>
                     </div>
                     <!-- <div></div> -->
                     <div style="height: 20px;"></div>
                   </section>
                  </div>
                    <!-- +++++++++++++++++++++ tab one ++++++++++++++++++++++ -->
                    <!-- +++++++++++++++++++++ tab two ++++++++++++++++++++++ -->
            </div>
         </div>
         <!-- -------------end---------------- -->
      </div>
      <!-- +++++++++++++++++++ code end +++++++++++++++++ -->
      <script src="assets/jquery/jquery.js"></script>
      <script src="plugins/fancybox/jquery.fancybox.min.js"></script>
      <script src="plugins/nice-select/jquery.nice-select.min.js"></script>
      <script src="plugins/aos/aos.min.js"></script>
      <script src="plugins/slick/slick.min.js"></script>
      <script src="plugins/counter-up/jquery.counterup.min.js"></script>
      <script src="plugins/counter-up/jquery.waypoints.min.js"></script>
      <script src="plugins/ui-range-slider/jquery-ui.js"></script>
      <script src="js/custom.js"></script>
      <script>
         $(document).ready(function () {
           $('#toggle_btn').click(function () {
             $('#cm_3_id').toggleClass('invisible');
             $('#cm_4_id').toggleClass('invisibleTwo');
           })
         });

         function count_job() {
           $.ajax({
            url: 'ajaxfils/count_job.php',
            type: 'POST',
            success: function (data) {
              $('#set_job_count').html(data);
            }
           })
         }
         count_job();

         function count_applicants() {
           $.ajax({
            url: 'ajaxfils/count_applicants.php',
            type: 'POST',
            success: function (data) {
              $('#set_applicants_count').html(data);
            }
           })
         }
         count_applicants();
         

      </script>
      <script type="text/javascript">
         $(function($) {
            let url = window.location.href;
            $('ul.admin_ul li a').each(function() {
              if (this.href === url) {
                $(this).closest('a').addClass('active_nav_admin');
              }
            });
          });
      </script>
   </body>
</html>