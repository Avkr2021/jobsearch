<!doctype html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <meta name="robots" content="noindex" />
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
      <link rel="stylesheet" href="assets/css/style.css">
      <!-- <link rel="shortcut icon" href="image/favicon.png" type="image/x-icon"> -->
      <!-- Bootstrap , fonts & icons  -->
      <link rel="stylesheet" href="css/bootstrap.css">
      <link rel="stylesheet" href="fonts/icon-font/css/style.css">
      <link rel="stylesheet" href="fonts/typography-font/typo.css">
      <link rel="stylesheet" href="fonts/fontawesome-5/css/all.css">
      <!-- Plugin'stylesheets  -->
      <link rel="stylesheet" href="plugins/fancybox/jquery.fancybox.min.css">
      <link rel="stylesheet" href="plugins/nice-select/nice-select.min.css">
      <link rel="stylesheet" href="plugins/slick/slick.min.css">
      <link rel="stylesheet" href="plugins/ui-range-slider/jquery-ui.css">
      <!-- Vendor stylesheets  -->
      <link rel="stylesheet" href="css/main.css">
      <!-- Custom stylesheet -->
      <title>Developer Testing</title>
      <style>
 

      </style>
   </head>
   <body>
      <?php include 'includes/navbar.php' ?>
      <!-- +++++++++++++  header end +++++++++++ -->
      <section class="contact_top_image">
         <div class="container-fluid">
            <div class="row">
               <div class="col-12">
                  <h2 class="font-size-9 text-center contact_heading">Contact Us</h2>
               </div>
            </div>
         </div>
      </section>
      <section>
         <div class="container">
           <div class="row justify-content-center mt-14">
             <div class="col-xxl-6 col-xl-7 col-lg-8 d-flex align-items-center">
                <div class="get_email_text">
                   <div class="content-2 pr-lg-5 pr-xl-18 pr-xxl-10 text-center text-lg-left">
                    <p class="text-white font-size-4 font-weight-semibold mb-8">
                      Looking for an expert for your company?
                    </p>
                    <h2 class="font-size-9 mb-8">
                      Get applications from the world best talents.
                    </h2>
                    <p class="font-size-5 mb-12">
                      Capitalize on low hanging fruit to identify a ballpark value added activity to beta test.
                      Override the digital divide with additional clickthroughs from DevOps.
                    </p>
                    <a class="btn btn-green btn-h-60 btn-primary w-180 rounded-5 text-uppercase mx-auto mx-lg-0" href="#">Post a Job</a>
                  </div>
                </div>
             </div>
             <div class="col-xxl-6 col-xl-7 col-lg-8">
               <div class="bg-white px-9 pt-9 pb-7 contact_box_shadow rounded-4">
                 <form id="company_form">
                   <div class="row">
                     <div class="col-12 mb-7">
                       <label for="" class="font-size-4 font-weight-semibold text-black-2 mb-5 line-height-reset">Name or Company Name</label>
                       <input id="name_company" type="text" class="form-control" placeholder="Jhon Doe" required>
                     </div>
                     <div class="col-lg-6 mb-7">
                       <label for="" class="font-size-4 font-weight-semibold text-black-2 mb-5 line-height-reset">E-mail</label>
                       <input id="email_company" type="email" class="form-control" placeholder="example@gmail.com" required>
                     </div>
                     <div class="col-lg-6 mb-7">
                       <label for="" class="font-size-4 font-weight-semibold text-black-2 mb-5 line-height-reset">Subject</label>
                       <input id="subject_company" type="text" class="form-control" placeholder="Special contract" required>
                     </div>
                     <div class="col-lg-12 mb-7">
                       <label for="message" class="font-size-4 font-weight-semibold text-black-2 mb-5 line-height-reset">Message</label>
                       <textarea id="message_company" placeholder="Type your message" class="form-control h-px-144" required></textarea>
                     </div>
                     <div class="col-lg-12 pt-4">
                       <button id="submit_company" class="btn btn-primary text-uppercase w-100 h-px-48">Send Now</button>
                     </div>
                   </div>
                 </form>
               </div>
             </div>
           </div>
         </div>
      </section>
      <!-- +++++++++++++  footer +++++++++++ -->
      <?php include 'includes/footer.php' ?>
      <!-- +++++++++++++ footer +++++++++++++++++ -->
      <script src="assets/jquery/jquery.js"></script>
      <script src="plugins/fancybox/jquery.fancybox.min.js"></script>
      <script src="plugins/nice-select/jquery.nice-select.min.js"></script>
      <script src="plugins/aos/aos.min.js"></script>
      <script src="plugins/slick/slick.min.js"></script>
      <script src="plugins/counter-up/jquery.counterup.min.js"></script>
      <script src="plugins/counter-up/jquery.waypoints.min.js"></script>
      <script src="plugins/ui-range-slider/jquery-ui.js"></script>
      <script src="js/custom.js"></script>

      <script>
         // Contact us form velidation --------------
         $(document).ready(function () {
            $('#company_form').submit(function (e) {
              e.preventDefault();
              var nameCm = $('#name_company').val();
              var emailCm = $('#email_company').val();
              var subjectCm = $('#subject_company').val();
              var messageCm = $('#message_company').val();
              if (nameCm !== '' && emailCm !== '' && subjectCm !== '' && messageCm !== '') {
               if (nameCm.search(/[!\"\#\$\%\&\'\(\)\*\+\,\-\.\/\:\;\<\=\>\?\@\[\\\]\^\_\`\{\|\}\~]/) == -1  && subjectCm.search(/[!\"\#\$\%\&\'\(\)\*\+\,\-\/\:\;\<\=\>\?\@\[\\\]\^\_\`\{\|\}\~]/) == -1) {
                  if (emailCm.search(/[\.\~]/) !== -1 && emailCm.search(/[\@\~]/) !== -1) {
                    $.ajax({
                        url: 'ajaxfils/companymail.php',
                        type: 'POST',
                        data: {nameCm_key: nameCm, emailCm_key: emailCm, subjectCm_key: subjectCm, messageCm_key: messageCm},
                        success: function (data) {
                           if (data == 1) {
                            alert('Messages sent successfully');
                            $('#company_form').trigger('reset');
                           } else {
                            alert("Can't Send Text Messages")
                           }
                        }
                    });
                  } else {
                     alert('invalid email')
                  }
               } else {
                  alert('Please Write a valid Name and Subject dont use any special characters');
               }
              } else {
               alert('Please Fill All Fields')
              }
              
            })
         })
// (last_driver_passwor_ph.search(/[ !\"\#\$\%\&\'\(\)\*\+\,\-\.\/\:\;\<\=\>\?\@\[\\\]\^\_\`\{\|\}\~]/) !== -1)
      </script>
   </body>
</html>