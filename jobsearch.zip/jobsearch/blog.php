<!doctype html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
      <meta name="robots" content="noindex" />
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
      <link rel="stylesheet" href="assets/css/style.css">
      <!-- <link rel="shortcut icon" href="image/favicon.png" type="image/x-icon"> -->
      <!-- Bootstrap , fonts & icons  -->
      <link rel="stylesheet" href="css/bootstrap.css">
      <link rel="stylesheet" href="fonts/icon-font/css/style.css">
      <link rel="stylesheet" href="fonts/typography-font/typo.css">
      <link rel="stylesheet" href="fonts/fontawesome-5/css/all.css">
      <!-- Plugin'stylesheets  -->
      <link rel="stylesheet" href="plugins/fancybox/jquery.fancybox.min.css">
      <link rel="stylesheet" href="plugins/nice-select/nice-select.min.css">
      <link rel="stylesheet" href="plugins/slick/slick.min.css">
      <link rel="stylesheet" href="plugins/ui-range-slider/jquery-ui.css">
      <!-- Vendor stylesheets  -->
      <link rel="stylesheet" href="css/main.css">
      <!-- Custom stylesheet -->
      <title>Developer Testing</title>
      <style>
 

      </style>
   </head>
   <body>
      <?php include 'includes/navbar.php' ?>
      <!-- +++++++++++++  header end +++++++++++ -->
      <section class="contact_top_image_blogs">
         <div class="container-fluid">
            <div class="row">
               <div class="col-12">
                  <h2 class="font-size-9 text-center contact_heading">Blog</h2>
               </div>
            </div>
         </div>
      </section>
      <section>
<div class="container">
	<div class="row">
		<div class="col-md-6 m-auto">
			<div class="r-bg-x pb120">		
	<div class="container w-992">
		<div class="blog-details">
			<div class="row">
				<div class="col-lg-12">
					<div class="sol-img mt60">
						<div style="background-image: url(images/blogs/blog-details-1.jpg); background-repeat: no-repeat;
				          background-position: center;
				          background-size: cover;
				          height: 250px;
				          width: 100%;
				          "></div> </div>
					<div class="ree-blog-details">
						<div class="info-bar">
							<div class="info-b-left"> <a href="#">#Marketing</a> <a href="#">#Seo</a>  </div>
							<div class="info-b-right">By <a href="#">John Doe</a> • <span>4 days ago</span> </div>
						</div>
						
						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
						
						<h4>Website – The quickest way to take your business online</h4>
						
						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
						
						<!-- <ul class="ul-list mb30">
							<li>A Logical Roadmap</li>
							<li>Crucial Business Information</li>
							<li>Social Media Integration</li>
							<li>A Mobile-Ready Version</li>
							<li>Heading and tagline or USP</li>
							<li>Testimonials and social proof</li>
							<li>Optimise website speed and performance</li>
							<li>Contact Information and Clear Navigation</li>
							<li>Ability to easily update title tag and meta description</li>
						</ul> -->

						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
						
						<div class="sol-img mt45 mb10"> <img src="images/blogs/blog-details-2.jpg" alt="blog" class="img-fluid"> </div>

						<p class="small text-center pb25"> Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>


						<h4>Preparing for the perfect brand strategy.</h4>

						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>

						<h6>1.  The most downloaded graphic resource</h6>

						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>

						<h6>2.  The most downloaded graphic resource</h6>

						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>

						<h6>3.  The most downloaded graphic resource</h6>

						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>


						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>


						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
						
					</div>

					<div class="center-btn"> <a href="blog.html" class="ree-btn  ree-btn-grdt2 mr20">Back to Blogs <i class="fas fa-arrow-left fa-btn"></i></a> </div>

				</div>
			</div>
			</div>
			</div>
		</div>
		</div>
		<!-- ------------- main 4 column -------------------- -->
		<div class="col-md-4 sticky-top">
			<div class="row">
				<div class="col-10 ml-auto mb-3">
					<div class="half-blog-card mt60">
				      <div class="half-blog-img"> <a href="blog-details.htmle"><div style="background-image: url(images/blogs/blog-img-1.jpg); background-repeat: no-repeat;
				          background-position: center;
				          background-size: cover;
				          height: 170px;
				          width: 100%;
				          "></div> </a> </div>
				      <div class="half-blog-content">
				        <div class="blog-quick-inf mb20"><span><i class="far fa-calendar-alt"></i> 12 March 21</span> <span><i class="fas fa-clock"></i> 5 Min Read</span> </div>
				        <h4 class="mb15"><a href="blog-details.htmle">Best Technology for Mobile Application Development</a></h4>
				        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget	dolor.</p>
				      </div>
				    </div>
				</div>
				<div class="col-10 ml-auto mb-3">
					<div class="half-blog-card">
				      <div class="half-blog-img"> <a href="blog-details.htmle"><img src="images/blogs/blog-img-1.jpg" alt="blogs" class="img-fluid"> </a> </div>
				      <div class="half-blog-content">
				        <div class="blog-quick-inf mb20"><span><i class="far fa-calendar-alt"></i> 12 March 21</span> <span><i class="fas fa-clock"></i> 5 Min Read</span> </div>
				        <h4 class="mb15"><a href="blog-details.htmle">Best Technology for Mobile Application Development</a></h4>
				        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget	dolor.</p>
				      </div>
				    </div>
				</div>
				<div class="col-10 ml-auto mb-3">
					<div class="half-blog-card">
				      <div class="half-blog-img"> <a href="blog-details.htmle"><img src="images/blogs/blog-img-1.jpg" alt="blogs" class="img-fluid"> </a> </div>
				      <div class="half-blog-content">
				        <div class="blog-quick-inf mb20"><span><i class="far fa-calendar-alt"></i> 12 March 21</span> <span><i class="fas fa-clock"></i> 5 Min Read</span> </div>
				        <h4 class="mb15"><a href="blog-details.htmle">Best Technology for Mobile Application Development</a></h4>
				        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget	dolor.</p>
				      </div>
				    </div>
				</div>
			</div>
		</div>

	</div>
</div>
</section>
		<!-- +++++++++++++  footer +++++++++++ -->
      <?php include 'includes/footer.php' ?>
      <!-- +++++++++++++ footer +++++++++++++++++ -->
      <script src="assets/jquery/jquery.js"></script>
      <script src="plugins/fancybox/jquery.fancybox.min.js"></script>
      <script src="plugins/nice-select/jquery.nice-select.min.js"></script>
      <script src="plugins/aos/aos.min.js"></script>
      <script src="plugins/slick/slick.min.js"></script>
      <script src="plugins/counter-up/jquery.counterup.min.js"></script>
      <script src="plugins/counter-up/jquery.waypoints.min.js"></script>
      <script src="plugins/ui-range-slider/jquery-ui.js"></script>
      <script src="js/custom.js"></script>
      <script>

      </script>
   </body>
</html>